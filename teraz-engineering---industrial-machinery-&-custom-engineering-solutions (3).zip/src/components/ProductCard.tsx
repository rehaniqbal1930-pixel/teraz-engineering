import React from 'react';
import { ArrowRight, Settings, CheckCircle2 } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onSelectProduct: (slug: string) => void;
  onRequestQuote: (productName: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelectProduct,
  onRequestQuote,
}) => {
  const handleClick = (e: React.MouseEvent) => {
    // Prevent routing if user clicked direct quote button
    if ((e.target as HTMLElement).closest('.btn-quote-prevent-nav')) {
      return;
    }
    onSelectProduct(product.slug);
  };

  return (
    <div
      id={`product-card-${product.slug}`}
      onClick={handleClick}
      className="group flex flex-col bg-white rounded-lg border border-[#D9E1E8] hover:border-[#1565C0] transition-all duration-200 overflow-hidden cursor-pointer shadow-sm hover:shadow-md"
    >
      {/* Product Image Area */}
      <div className="relative aspect-[4/3] bg-[#0B1F33]/5 overflow-hidden border-b border-[#D9E1E8]">
        <img
          src={product.mainImage}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        {/* Category Pill */}
        <div className="absolute top-3 left-3">
          <span className="inline-block px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider bg-[#0B1F33]/90 text-white rounded backdrop-blur-sm shadow-sm">
            {product.category}
          </span>
        </div>

        {/* Hover quick view overlay hint */}
        <div className="absolute inset-0 bg-[#0B1F33]/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="px-3 py-1.5 bg-[#0B1F33] text-white text-xs font-semibold rounded shadow-md flex items-center gap-1.5">
            View Complete Specs <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>

      {/* Card Content Area */}
      <div className="flex-1 flex flex-col p-5">
        {/* Machine Title */}
        <h3 className="text-lg font-bold text-[#0B1F33] group-hover:text-[#1565C0] transition-colors line-clamp-2 mb-2 leading-snug">
          {product.name}
        </h3>

        {/* Short Description */}
        <p className="text-xs text-[#667085] line-clamp-3 mb-4 flex-1 leading-relaxed">
          {product.shortDescription}
        </p>

        {/* Top 2 Key Features Quick Tags */}
        <div className="space-y-1.5 mb-5 pb-4 border-b border-[#F4F7FA]">
          {product.features.slice(0, 2).map((feat, idx) => (
            <div key={idx} className="flex items-start gap-1.5 text-[11px] text-[#1F2933]">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#1565C0] flex-shrink-0 mt-0.5" />
              <span className="line-clamp-1">{feat}</span>
            </div>
          ))}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 pt-1">
          <button
            id={`view-details-${product.slug}`}
            onClick={(e) => {
              e.stopPropagation();
              onSelectProduct(product.slug);
            }}
            className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 bg-[#F4F7FA] hover:bg-[#1565C0] text-[#1565C0] hover:text-white text-xs font-bold rounded border border-[#D9E1E8] hover:border-[#1565C0] transition-colors"
          >
            <span>View Details</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            id={`quote-btn-${product.slug}`}
            onClick={(e) => {
              e.stopPropagation();
              onRequestQuote(product.name);
            }}
            className="btn-quote-prevent-nav px-3.5 py-2.5 bg-[#0B1F33] hover:bg-[#17212B] text-white text-xs font-bold rounded transition-colors shadow-sm"
            title="Request Instant Machine Quote"
          >
            Quote
          </button>
        </div>
      </div>
    </div>
  );
};
