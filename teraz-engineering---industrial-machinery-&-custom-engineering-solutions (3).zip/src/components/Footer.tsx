import React from 'react';
import { PhoneCall, Mail, MapPin, Clock, ArrowRight, MessageSquare, ShieldCheck } from 'lucide-react';
import { TerazLogo } from './TerazLogo';
import { COMPANY_INFO, PRODUCTS } from '../data/products';

interface FooterProps {
  onNavigate: (route: string) => void;
  onRequestQuote: (productName?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onRequestQuote }) => {
  return (
    <footer className="bg-[#0B1F33] text-white border-t-4 border-[#1565C0]">
      {/* Upper CTA Banner */}
      <div className="bg-[#17212B] py-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#2196F3]">
              DIRECT KARACHI WORKSHOP INQUIRIES
            </span>
            <h3 className="text-xl sm:text-2xl font-bold mt-1 text-white">
              Need a Custom Engineered Machinery Solution?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
              Discuss your batch size, material specifications, or factory floor space with Muhammad Iqbal and our Karachi engineering team.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onRequestQuote()}
              className="px-5 py-3 bg-[#1565C0] hover:bg-[#2196F3] text-white text-xs font-bold rounded-lg transition-colors shadow-md"
            >
              Request Custom Quote
            </button>
            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-2 shadow-md"
            >
              <MessageSquare className="w-4 h-4" />
              WhatsApp Direct
            </a>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Col 1: Brand & Identity */}
          <div>
            <TerazLogo className="h-12 mb-4" variant="light" />
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              TERAZ ENGINEERING is a premier industrial machinery manufacturer and custom engineering firm based in SITE Industrial Area, Karachi, Pakistan. We engineer durable stainless steel and fabricated steel machinery for Food, Textile, Pharma, and Chemical industries.
            </p>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-[#2196F3]" />
              <span>Founded by Muhammad Iqbal in 2022</span>
            </div>
          </div>

          {/* Col 2: Core Machinery Catalog */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#38BDF8] mb-4">
              Featured Machinery
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              {PRODUCTS.slice(0, 7).map((prod) => (
                <li key={prod.id}>
                  <button
                    onClick={() => onNavigate(`/products/${prod.slug}`)}
                    className="hover:text-white hover:underline transition-colors text-left flex items-center gap-1.5"
                  >
                    <ArrowRight className="w-3 h-3 text-[#1565C0]" />
                    <span className="truncate">{prod.name.split('(')[0].trim()}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: More Machinery & Services */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#38BDF8] mb-4">
              Systems & Processing
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              {PRODUCTS.slice(7, 14).map((prod) => (
                <li key={prod.id}>
                  <button
                    onClick={() => onNavigate(`/products/${prod.slug}`)}
                    className="hover:text-white hover:underline transition-colors text-left flex items-center gap-1.5"
                  >
                    <ArrowRight className="w-3 h-3 text-[#1565C0]" />
                    <span className="truncate">{prod.name.split('(')[0].trim()}</span>
                  </button>
                </li>
              ))}
              <li className="pt-2">
                <button
                  onClick={() => onNavigate('/custom-engineering')}
                  className="text-xs font-bold text-[#38BDF8] hover:underline flex items-center gap-1"
                >
                  Turnkey Plant & Custom Fabrication →
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Verified Contact Info */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#38BDF8] mb-4">
              Karachi Workshop Contact
            </h4>
            <div className="space-y-3.5 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#2196F3] flex-shrink-0 mt-0.5" />
                <span>
                  {COMPANY_INFO.address}
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <PhoneCall className="w-4 h-4 text-[#2196F3] flex-shrink-0" />
                <a
                  href={`tel:${COMPANY_INFO.phoneRaw}`}
                  className="hover:text-white font-bold transition-colors"
                >
                  {COMPANY_INFO.phone}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#2196F3] flex-shrink-0" />
                <a
                  href={`mailto:${COMPANY_INFO.email}`}
                  className="hover:text-white transition-colors"
                >
                  {COMPANY_INFO.email}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#2196F3] flex-shrink-0" />
                <span>{COMPANY_INFO.businessHours}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Legal & Verification Preserved */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3">
          <p>
            © {new Date().getFullYear()} TERAZ ENGINEERING. All Rights Reserved. Custom Machinery Solutions. Karachi, Pakistan.
          </p>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Google Search Console Verified</span>
            <span>•</span>
            <span>Food, Textile, Pharma & Chemical Fabrication</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
