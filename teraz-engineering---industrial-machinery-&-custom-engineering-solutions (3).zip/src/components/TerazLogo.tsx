import React from 'react';

interface TerazLogoProps {
  className?: string;
  variant?: 'light' | 'dark' | 'full';
  showTagline?: boolean;
}

export const TerazLogo: React.FC<TerazLogoProps> = ({
  className = 'h-10',
  variant = 'dark',
  showTagline = true,
}) => {
  const isLight = variant === 'light';
  const navyColor = isLight ? '#FFFFFF' : '#0B2A4A';
  const grayColor = isLight ? '#94A3B8' : '#525F70';
  const accentBlue = '#1565C0';

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* SVG Icon: Gear with stylized TE monogram */}
      <svg
        viewBox="0 0 160 160"
        className="h-full w-auto aspect-square flex-shrink-0"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="TERAZ ENGINEERING Logo Icon"
      >
        {/* Outer Gear Teeth (12 teeth) */}
        <path
          d="M 72 6 L 88 6 L 86 18 C 93 20 99 23 105 27 L 115 20 L 126 31 L 119 41 C 123 47 126 53 128 60 L 140 58 L 140 74 L 128 76 C 126 83 123 89 119 95 L 126 105 L 115 116 L 105 109 C 99 113 93 116 86 118 L 88 130 L 72 130 L 74 118 C 67 116 61 113 55 109 L 45 116 L 34 105 L 41 95 C 37 89 34 83 32 76 L 20 74 L 20 58 L 32 60 C 34 53 37 47 41 41 L 34 31 L 45 20 L 55 27 C 61 23 67 20 74 18 Z"
          fill={navyColor}
          transform="scale(1.15) translate(-10, -5)"
        />
        {/* Inner cutout circle */}
        <circle cx="80" cy="74" r="48" fill={isLight ? '#0B1F33' : '#FFFFFF'} />

        {/* Dynamic sweeping swoosh curve */}
        <path
          d="M 40 86 C 45 102 65 114 90 106 C 104 101 116 90 120 78 C 114 86 100 95 86 96 C 62 98 47 88 40 86 Z"
          fill={grayColor}
        />
        <path
          d="M 36 94 C 42 110 65 120 92 111 C 104 107 114 99 118 89 C 111 96 98 103 84 103 C 60 103 45 94 36 94 Z"
          fill={isLight ? '#38BDF8' : '#7D8B9B'}
          opacity="0.7"
        />

        {/* Stylized 'T' */}
        <path
          d="M 46 44 L 84 44 L 81 53 L 68 53 L 61 98 L 50 98 L 57 53 L 44 53 Z"
          fill={navyColor}
        />

        {/* Stylized 'E' */}
        <path
          d="M 80 44 L 114 44 L 111 53 L 90 53 L 88 64 L 107 64 L 105 72 L 87 72 L 83 98 L 73 98 L 79 53 Z"
          fill={grayColor}
        />
        <path
          d="M 83 89 L 115 89 L 113 98 L 75 98 L 76 89 Z"
          fill={grayColor}
        />
      </svg>

      {/* Typography block */}
      <div className="flex flex-col justify-center">
        {/* TERAZ wordmark */}
        <div className="flex items-baseline tracking-wider font-extrabold text-2xl leading-none" style={{ color: navyColor }}>
          <span className="tracking-tight font-black text-[1.45rem]">TER</span>
          {/* Custom 'A' with solid triangle cutout */}
          <span className="relative inline-block mx-[1px] font-black text-[1.45rem]">
            A
            <span
              className="absolute top-[32%] left-[29%] w-[42%] h-[30%] pointer-events-none"
              style={{
                clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
                backgroundColor: grayColor,
              }}
            />
          </span>
          <span className="tracking-tight font-black text-[1.45rem]">Z</span>
        </div>

        {/* ENGINEERING text */}
        <span
          className="text-[0.72rem] font-bold tracking-[0.24em] uppercase leading-tight mt-[2px]"
          style={{ color: grayColor }}
        >
          ENGINEERING
        </span>

        {/* Tagline */}
        {showTagline && (
          <div className="flex items-center gap-1.5 mt-1">
            <div className="h-[1px] w-3" style={{ backgroundColor: accentBlue }} />
            <span
              className="text-[0.52rem] font-bold tracking-[0.18em] uppercase whitespace-nowrap"
              style={{ color: isLight ? '#E2E8F0' : '#1565C0' }}
            >
              CUSTOM MACHINERY SOLUTIONS
            </span>
            <div className="h-[1px] w-3" style={{ backgroundColor: accentBlue }} />
          </div>
        )}
      </div>
    </div>
  );
};
