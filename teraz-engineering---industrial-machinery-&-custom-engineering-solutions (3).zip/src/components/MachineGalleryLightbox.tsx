import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from 'lucide-react';

interface MachineGalleryLightboxProps {
  images: {
    url: string;
    alt: string;
    caption?: string;
  }[];
  initialIndex: number;
  isOpen: boolean;
  onClose: () => void;
  productName: string;
}

export const MachineGalleryLightbox: React.FC<MachineGalleryLightboxProps> = ({
  images,
  initialIndex,
  isOpen,
  onClose,
  productName,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [isZoomed, setIsZoomed] = useState(false);
  const touchStartX = useRef<number | null>(null);

  useEffect(() => {
    setCurrentIndex(initialIndex);
    setIsZoomed(false);
  }, [initialIndex, isOpen]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowRight') {
        setCurrentIndex((prev) => (prev + 1) % images.length);
        setIsZoomed(false);
      } else if (e.key === 'ArrowLeft') {
        setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
        setIsZoomed(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    // Prevent body scroll when modal is open
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, images.length, onClose]);

  if (!isOpen || images.length === 0) return null;

  const currentImg = images[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    setIsZoomed(false);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
    setIsZoomed(false);
  };

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        handleNext(); // swipe left -> next
      } else {
        handlePrev(); // swipe right -> prev
      }
    }
    touchStartX.current = null;
  };

  return (
    <div
      id="machinery-lightbox-modal"
      className="fixed inset-0 z-50 flex flex-col justify-between bg-[#0B1F33]/95 backdrop-blur-md text-white transition-opacity duration-200"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Top Bar: Title, Image Counter, Zoom & Close */}
      <div className="flex items-center justify-between px-4 py-3 sm:px-6 bg-[#0B1F33]/80 border-b border-[#1E3A5F]">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#38BDF8] bg-[#1565C0]/30 px-2.5 py-1 rounded border border-[#1565C0]/40">
            {productName}
          </span>
          <span className="text-sm font-mono text-slate-300">
            {currentIndex + 1} / {images.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="lightbox-zoom-toggle-btn"
            onClick={() => setIsZoomed(!isZoomed)}
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title={isZoomed ? 'Zoom Out' : 'Zoom In'}
            aria-label={isZoomed ? 'Zoom Out' : 'Zoom In'}
          >
            {isZoomed ? <ZoomOut className="w-5 h-5 text-[#38BDF8]" /> : <ZoomIn className="w-5 h-5" />}
          </button>
          <button
            id="lightbox-close-btn"
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white hover:bg-red-900/40 rounded-lg transition-colors"
            title="Close Gallery (Esc)"
            aria-label="Close Gallery"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="relative flex-1 flex items-center justify-center p-2 sm:p-6 overflow-hidden">
        {/* Previous Button */}
        <button
          id="lightbox-prev-btn"
          onClick={handlePrev}
          className="absolute left-2 sm:left-6 z-10 p-3 rounded-full bg-[#1565C0]/80 hover:bg-[#1565C0] text-white shadow-xl transition-transform active:scale-95 focus:outline-none focus:ring-2 focus:ring-[#38BDF8]"
          aria-label="Previous image"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        {/* Current Image */}
        <div
          className={`relative max-w-5xl max-h-[75vh] flex items-center justify-center transition-all duration-300 ${
            isZoomed ? 'scale-125 cursor-zoom-out' : 'cursor-zoom-in'
          }`}
          onClick={() => setIsZoomed(!isZoomed)}
        >
          <img
            src={currentImg.url}
            alt={currentImg.alt}
            className="max-h-[72vh] max-w-full object-contain rounded-lg shadow-2xl border border-slate-700/60 select-none"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Next Button */}
        <button
          id="lightbox-next-btn"
          onClick={handleNext}
          className="absolute right-2 sm:right-6 z-10 p-3 rounded-full bg-[#1565C0]/80 hover:bg-[#1565C0] text-white shadow-xl transition-transform active:scale-95 focus:outline-none focus:ring-2 focus:ring-[#38BDF8]"
          aria-label="Next image"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Bottom Thumbnail Strip & Caption */}
      <div className="bg-[#081726] border-t border-[#1E3A5F] px-4 py-3">
        {currentImg.caption && (
          <p className="text-center text-xs sm:text-sm text-slate-300 mb-2 font-medium">
            {currentImg.caption}
          </p>
        )}

        <div className="flex justify-center items-center gap-2 overflow-x-auto pb-1 max-w-2xl mx-auto">
          {images.map((img, idx) => (
            <button
              key={idx}
              onClick={() => {
                setCurrentIndex(idx);
                setIsZoomed(false);
              }}
              className={`relative flex-shrink-0 w-16 h-12 rounded overflow-hidden border-2 transition-all ${
                currentIndex === idx
                  ? 'border-[#2196F3] ring-2 ring-[#2196F3]/50 scale-105 opacity-100'
                  : 'border-slate-700 opacity-60 hover:opacity-100'
              }`}
            >
              <img
                src={img.url}
                alt={img.alt}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
