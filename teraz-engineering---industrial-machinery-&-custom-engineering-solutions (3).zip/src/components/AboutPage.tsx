import React from 'react';
import { ShieldCheck, Award, Factory, Users, CheckCircle2, PhoneCall, MessageSquare } from 'lucide-react';
import { COMPANY_INFO } from '../data/products';

interface AboutPageProps {
  onNavigate: (route: string) => void;
  onRequestQuote: (productName?: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate, onRequestQuote }) => {
  return (
    <div className="bg-[#F4F7FA] min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-[#0B1F33] text-white rounded-2xl p-8 sm:p-12 mb-12 shadow-xl">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-widest text-[#38BDF8]">
              ESTABLISHED 2022 • KARACHI, PAKISTAN
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold mt-2 mb-4 text-white">
              About TERAZ ENGINEERING
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Founded by mechanical engineering specialist Muhammad Iqbal in 2022, TERAZ ENGINEERING has grown into one of Karachi's most trusted manufacturers of heavy-duty industrial processing, mixing, conveying, and custom manufacturing machinery.
            </p>
          </div>
        </div>

        {/* Company Profile Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
          <div className="lg:col-span-7 bg-white rounded-xl border border-[#D9E1E8] p-8 shadow-sm space-y-4 text-sm text-[#1F2933] leading-relaxed">
            <h2 className="text-2xl font-bold text-[#0B1F33] mb-2">
              Engineering Precision from the Industrial Hub of Pakistan
            </h2>
            <p>
              Located in SITE Industrial Area Karachi, our facility is equipped with state-of-the-art metal forming, welding, precision machining, and dynamic balancing equipment. We manufacture process machinery that meets international sanitary standards for food, pharmaceutical, textile, and chemical plants.
            </p>
            <p>
              Rather than offering generic one-size-fits-all machinery, TERAZ ENGINEERING operates on an engineering-first philosophy. We work directly with plant engineers, procurement directors, and entrepreneurs across Pakistan to build machinery optimized for local electrical voltages, raw material bulk densities, and continuous duty cycles.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-[#D9E1E8]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0]" />
                <span className="font-semibold text-xs text-[#0B1F33]">ASME-standard Argon TIG Welding</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0]" />
                <span className="font-semibold text-xs text-[#0B1F33]">AISI 304 / 316 Stainless Steel</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0]" />
                <span className="font-semibold text-xs text-[#0B1F33]">Heavy Structural Mild Steel Frames</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0]" />
                <span className="font-semibold text-xs text-[#0B1F33]">Comprehensive Factory Testing (FAT)</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-white rounded-xl border border-[#D9E1E8] p-8 shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
                FOUNDER & LEAD ENGINEER
              </span>
              <h3 className="text-xl font-bold text-[#0B1F33] mt-1 mb-3">
                Muhammad Iqbal
              </h3>
              <p className="text-xs text-[#667085] leading-relaxed mb-6">
                "Our mission at TERAZ ENGINEERING is to provide Pakistani industries with machinery that matches or exceeds foreign imports in durability, hygiene, and efficiency—backed by local engineering support and immediate spare parts."
              </p>

              <div className="bg-[#F4F7FA] p-4 rounded-lg border border-[#D9E1E8] space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Headquarters:</span>
                  <span className="font-bold text-[#0B1F33]">SITE Area, Karachi</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Year Established:</span>
                  <span className="font-bold text-[#0B1F33]">2022</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Direct Inquiries:</span>
                  <span className="font-bold text-[#1565C0]">{COMPANY_INFO.phone}</span>
                </div>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-[#D9E1E8] flex gap-3">
              <button
                onClick={() => onRequestQuote()}
                className="flex-1 py-2.5 bg-[#1565C0] hover:bg-[#0B2A4A] text-white text-xs font-bold rounded-lg shadow-sm"
              >
                Request Quote
              </button>
              <a
                href={COMPANY_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm text-center flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                WhatsApp
              </a>
            </div>
          </div>
        </div>

        {/* Manufacturing Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl border border-[#D9E1E8] shadow-sm">
            <Factory className="w-8 h-8 text-[#1565C0] mb-3" />
            <h3 className="text-base font-bold text-[#0B1F33] mb-1">In-House Manufacturing</h3>
            <p className="text-xs text-[#667085] leading-relaxed">
              Every stage—from raw steel cutting and forming to shaft lathe work and final polishing—happens under our direct supervision in Karachi.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-[#D9E1E8] shadow-sm">
            <ShieldCheck className="w-8 h-8 text-[#1565C0] mb-3" />
            <h3 className="text-base font-bold text-[#0B1F33] mb-1">Sanitary Certification Ready</h3>
            <p className="text-xs text-[#667085] leading-relaxed">
              Our stainless steel contact components are welded without crevices, mirror polished, and designed for easy CIP (Clean-In-Place) washdowns.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-[#D9E1E8] shadow-sm">
            <Award className="w-8 h-8 text-[#1565C0] mb-3" />
            <h3 className="text-base font-bold text-[#0B1F33] mb-1">Guaranteed Spare Parts</h3>
            <p className="text-xs text-[#667085] leading-relaxed">
              Zero downtime risk from foreign backorders. We maintain complete inventories of replacement ribbons, flightings, bearings, and seals in Karachi.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
