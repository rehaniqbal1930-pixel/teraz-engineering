import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './components/HomePage';
import { ProductDetailPage } from './components/ProductDetailPage';
import { AboutPage } from './components/AboutPage';
import { CustomEngineeringPage } from './components/CustomEngineeringPage';
import { ContactPage } from './components/ContactPage';
import { QuoteModal } from './components/QuoteModal';
import { SEOHead } from './components/SEOHead';
import { PRODUCTS } from './data/products';

export default function App() {
  // Parse initial route from pathname or hash
  const getInitialRoute = () => {
    const hash = window.location.hash.replace('#', '');
    if (hash && hash.startsWith('/')) return hash;
    const pathname = window.location.pathname;
    return pathname || '/';
  };

  const [currentRoute, setCurrentRoute] = useState<string>(getInitialRoute);
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);
  const [quoteProductName, setQuoteProductName] = useState<string>('');

  // Handle browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash && hash.startsWith('/')) {
        setCurrentRoute(hash);
      } else {
        setCurrentRoute(window.location.pathname || '/');
      }
    };

    window.addEventListener('popstate', handlePopState);
    window.addEventListener('hashchange', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('hashchange', handlePopState);
    };
  }, []);

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [currentRoute]);

  const navigate = (path: string) => {
    setCurrentRoute(path);
    try {
      window.history.pushState(null, '', path);
    } catch {
      window.location.hash = path;
    }
  };

  const handleSelectProduct = (slug: string) => {
    navigate(`/products/${slug}`);
  };

  const handleOpenQuoteModal = (productName?: string) => {
    setQuoteProductName(productName || '');
    setQuoteModalOpen(true);
  };

  // Determine active product if route is `/products/:slug`
  let activeProduct = null;
  const isProductDetail = currentRoute.startsWith('/products/');
  if (isProductDetail) {
    const slug = currentRoute.replace('/products/', '').split('/')[0].split('?')[0];
    activeProduct = PRODUCTS.find((p) => p.slug === slug) || null;
  }

  // Render appropriate view
  const renderContent = () => {
    if (isProductDetail) {
      if (activeProduct) {
        return (
          <ProductDetailPage
            product={activeProduct}
            onBackToProducts={() => navigate('/products')}
            onSelectProduct={handleSelectProduct}
            onRequestQuote={handleOpenQuoteModal}
          />
        );
      } else {
        // Fallback for unmatched product slug
        return (
          <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center bg-[#F4F7FA]">
            <h2 className="text-2xl font-bold text-[#0B1F33] mb-2">Machine Not Found</h2>
            <p className="text-sm text-[#667085] mb-6">
              The requested machinery page does not exist or has been relocated.
            </p>
            <button
              onClick={() => navigate('/products')}
              className="px-6 py-2.5 bg-[#1565C0] text-white text-xs font-bold rounded-lg shadow-sm"
            >
              Browse All 14 Machines
            </button>
          </div>
        );
      }
    }

    switch (currentRoute) {
      case '/about':
        return (
          <AboutPage
            onNavigate={navigate}
            onRequestQuote={handleOpenQuoteModal}
          />
        );
      case '/custom-engineering':
        return (
          <CustomEngineeringPage
            onRequestQuote={handleOpenQuoteModal}
          />
        );
      case '/contact':
        return (
          <ContactPage
            onRequestQuote={handleOpenQuoteModal}
          />
        );
      case '/products':
      case '/':
      default:
        return (
          <HomePage
            onSelectProduct={handleSelectProduct}
            onRequestQuote={handleOpenQuoteModal}
          />
        );
    }
  };

  return (
    <div className="flex flex-col min-h-screen font-sans bg-[#F4F7FA] text-[#1F2933] antialiased selection:bg-[#1565C0] selection:text-white">
      {/* Dynamic SEO Head and Structured Data */}
      <SEOHead
        product={activeProduct}
        canonicalPath={currentRoute}
      />

      {/* Global Navbar */}
      <Navbar
        currentRoute={currentRoute}
        onNavigate={navigate}
        onRequestQuote={handleOpenQuoteModal}
      />

      {/* Main Content Area */}
      <main className="flex-grow">{renderContent()}</main>

      {/* Global Footer */}
      <Footer
        onNavigate={navigate}
        onRequestQuote={handleOpenQuoteModal}
      />

      {/* Pre-populated Quotation Modal */}
      <QuoteModal
        isOpen={quoteModalOpen}
        onClose={() => setQuoteModalOpen(false)}
        defaultProductName={quoteProductName}
      />
    </div>
  );
}
