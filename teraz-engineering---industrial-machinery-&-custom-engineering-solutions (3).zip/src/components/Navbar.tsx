import React, { useState } from 'react';
import { Menu, X, PhoneCall, MessageSquare, FileText, ChevronDown } from 'lucide-react';
import { TerazLogo } from './TerazLogo';
import { COMPANY_INFO, PRODUCTS } from '../data/products';

interface NavbarProps {
  currentRoute: string;
  onNavigate: (route: string) => void;
  onRequestQuote: (productName?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRoute,
  onNavigate,
  onRequestQuote,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProductsDropdownOpen, setIsProductsDropdownOpen] = useState(false);

  const handleNavClick = (route: string) => {
    onNavigate(route);
    setIsMobileMenuOpen(false);
    setIsProductsDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#D9E1E8] shadow-sm">
      {/* Top Utility Header Bar */}
      <div className="bg-[#0B1F33] text-white text-xs py-1.5 px-4 sm:px-6 lg:px-8 border-b border-[#17212B]">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline text-slate-300 font-medium">
              SITE Industrial Area, Karachi, Pakistan
            </span>
            <span className="hidden md:inline text-slate-400">•</span>
            <span className="hidden md:inline text-slate-300">
              Hours: {COMPANY_INFO.businessHours}
            </span>
          </div>

          <div className="flex items-center gap-4 ml-auto">
            <a
              href={`tel:${COMPANY_INFO.phoneRaw}`}
              className="flex items-center gap-1.5 text-slate-200 hover:text-white font-semibold transition-colors"
            >
              <PhoneCall className="w-3 h-3 text-[#2196F3]" />
              <span>{COMPANY_INFO.phone}</span>
            </a>
            <span className="text-slate-500">|</span>
            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
            >
              <MessageSquare className="w-3 h-3" />
              <span>WhatsApp Sales</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div
            onClick={() => handleNavClick('/')}
            className="cursor-pointer py-2 focus:outline-none"
            role="button"
            tabIndex={0}
            aria-label="TERAZ ENGINEERING Home"
          >
            <TerazLogo className="h-12" variant="dark" />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7">
            <button
              onClick={() => handleNavClick('/')}
              className={`text-sm font-bold transition-colors py-1 ${
                currentRoute === '/' ? 'text-[#1565C0] border-b-2 border-[#1565C0]' : 'text-[#1F2933] hover:text-[#1565C0]'
              }`}
            >
              Home
            </button>

            {/* Products Dropdown */}
            <div className="relative group">
              <button
                onClick={() => handleNavClick('/products')}
                onMouseEnter={() => setIsProductsDropdownOpen(true)}
                className={`flex items-center gap-1 text-sm font-bold transition-colors py-1 ${
                  currentRoute.startsWith('/products') ? 'text-[#1565C0] border-b-2 border-[#1565C0]' : 'text-[#1F2933] hover:text-[#1565C0]'
                }`}
              >
                <span>Machinery</span>
                <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-[#1565C0] transition-transform group-hover:rotate-180" />
              </button>

              {/* Dropdown Menu */}
              <div
                onMouseLeave={() => setIsProductsDropdownOpen(false)}
                className={`absolute top-full -left-4 w-72 bg-white rounded-lg shadow-xl border border-[#D9E1E8] py-2 transition-all duration-150 ${
                  isProductsDropdownOpen ? 'opacity-100 visible translate-y-0' : 'opacity-0 invisible -translate-y-2 pointer-events-none'
                }`}
              >
                <div className="px-3 py-1.5 border-b border-[#F4F7FA] text-[11px] font-bold uppercase tracking-wider text-[#667085]">
                  Industrial Machinery Catalog
                </div>
                <div className="max-h-80 overflow-y-auto py-1">
                  {PRODUCTS.map((prod) => (
                    <button
                      key={prod.id}
                      onClick={() => handleNavClick(`/products/${prod.slug}`)}
                      className="w-full text-left px-4 py-2 text-xs font-semibold text-[#1F2933] hover:bg-[#F4F7FA] hover:text-[#1565C0] transition-colors flex items-center justify-between"
                    >
                      <span className="truncate">{prod.name.split('(')[0].trim()}</span>
                    </button>
                  ))}
                </div>
                <div className="p-2 border-t border-[#D9E1E8] bg-[#F4F7FA]">
                  <button
                    onClick={() => handleNavClick('/products')}
                    className="w-full text-center py-1.5 text-xs font-bold text-[#1565C0] hover:underline"
                  >
                    View All 14 Machines →
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleNavClick('/about')}
              className={`text-sm font-bold transition-colors py-1 ${
                currentRoute === '/about' ? 'text-[#1565C0] border-b-2 border-[#1565C0]' : 'text-[#1F2933] hover:text-[#1565C0]'
              }`}
            >
              About TERAZ
            </button>

            <button
              onClick={() => handleNavClick('/custom-engineering')}
              className={`text-sm font-bold transition-colors py-1 ${
                currentRoute === '/custom-engineering' ? 'text-[#1565C0] border-b-2 border-[#1565C0]' : 'text-[#1F2933] hover:text-[#1565C0]'
              }`}
            >
              Custom Engineering
            </button>

            <button
              onClick={() => handleNavClick('/contact')}
              className={`text-sm font-bold transition-colors py-1 ${
                currentRoute === '/contact' ? 'text-[#1565C0] border-b-2 border-[#1565C0]' : 'text-[#1F2933] hover:text-[#1565C0]'
              }`}
            >
              Contact
            </button>
          </nav>

          {/* Desktop Right CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <button
              id="navbar-request-quote-btn"
              onClick={() => onRequestQuote()}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#1565C0] hover:bg-[#0B1F33] text-white font-bold text-xs rounded-lg transition-colors shadow-sm"
            >
              <FileText className="w-4 h-4" />
              Request a Quote
            </button>
          </div>

          {/* Mobile Hamburger Menu Button (Preserving three-line hamburger menu as requested) */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2.5 rounded-lg text-[#0B1F33] hover:bg-[#F4F7FA] border border-[#D9E1E8] focus:outline-none"
              aria-label={isMobileMenuOpen ? 'Close menu' : 'Open three-line navigation menu'}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-[#0B1F33]" />
              ) : (
                /* Standard three-line hamburger icon */
                <Menu className="w-6 h-6 text-[#0B1F33]" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div
          id="mobile-navigation-drawer"
          className="lg:hidden bg-white border-b border-[#D9E1E8] px-4 pt-3 pb-6 space-y-3 shadow-xl animate-fade-in"
        >
          <div className="space-y-1">
            <button
              onClick={() => handleNavClick('/')}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-bold ${
                currentRoute === '/' ? 'bg-[#1565C0] text-white' : 'text-[#1F2933] hover:bg-[#F4F7FA]'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('/products')}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-bold ${
                currentRoute.startsWith('/products') ? 'bg-[#1565C0] text-white' : 'text-[#1F2933] hover:bg-[#F4F7FA]'
              }`}
            >
              Machinery Catalog (All 14 Machines)
            </button>
            <button
              onClick={() => handleNavClick('/about')}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-bold ${
                currentRoute === '/about' ? 'bg-[#1565C0] text-white' : 'text-[#1F2933] hover:bg-[#F4F7FA]'
              }`}
            >
              About TERAZ ENGINEERING
            </button>
            <button
              onClick={() => handleNavClick('/custom-engineering')}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-bold ${
                currentRoute === '/custom-engineering' ? 'bg-[#1565C0] text-white' : 'text-[#1F2933] hover:bg-[#F4F7FA]'
              }`}
            >
              Custom Engineering & Fabrication
            </button>
            <button
              onClick={() => handleNavClick('/contact')}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-bold ${
                currentRoute === '/contact' ? 'bg-[#1565C0] text-white' : 'text-[#1F2933] hover:bg-[#F4F7FA]'
              }`}
            >
              Contact Karachi Workshop
            </button>
          </div>

          <div className="pt-3 border-t border-[#D9E1E8] space-y-2">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onRequestQuote();
              }}
              className="w-full flex items-center justify-center gap-2 py-3 bg-[#1565C0] text-white text-xs font-bold rounded-lg shadow-sm"
            >
              <FileText className="w-4 h-4" />
              Request a Machine Quote
            </button>

            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-emerald-600 text-white text-xs font-bold rounded-lg shadow-sm"
            >
              <MessageSquare className="w-4 h-4" />
              Chat on WhatsApp ({COMPANY_INFO.phone})
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
