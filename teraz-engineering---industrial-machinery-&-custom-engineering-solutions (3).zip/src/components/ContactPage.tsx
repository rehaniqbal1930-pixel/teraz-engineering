import React, { useState } from 'react';
import { MapPin, PhoneCall, Mail, Clock, MessageSquare, Send, CheckCircle2, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../data/products';

interface ContactPageProps {
  onRequestQuote: (productName?: string) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onRequestQuote }) => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello TERAZ ENGINEERING,\n\n*Inquiry from Website:*\n*Name:* ${formData.name || 'General Inquiry'}\n*Company:* ${formData.company || 'N/A'}\n*Subject:* ${formData.subject || 'Machinery Consultation'}\n*Message:* ${formData.message}`
    );
    window.open(`https://wa.me/923132513076?text=${text}`, '_blank');
  };

  return (
    <div className="bg-[#F4F7FA] min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Banner */}
        <div className="bg-[#0B1F33] text-white rounded-2xl p-8 sm:p-12 mb-12 shadow-xl">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-widest text-[#38BDF8]">
              DIRECT KARACHI WORKSHOP ACCESS
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold mt-2 mb-4 text-white">
              Contact TERAZ ENGINEERING
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Connect directly with our engineering workshop in SITE Area Karachi. We welcome machinery orders, quotation requests, on-site visits, and technical inquiries from across Pakistan.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Contact Details & Info (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-xl border border-[#D9E1E8] p-6 sm:p-8 shadow-sm space-y-6">
              <h2 className="text-xl font-bold text-[#0B1F33] border-b border-[#D9E1E8] pb-3">
                Factory & Office Details
              </h2>

              <div className="space-y-4 text-xs sm:text-sm text-[#1F2933]">
                {/* Location */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#1565C0]/10 text-[#1565C0] flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0B1F33]">Workshop Location</h3>
                    <p className="text-[#667085] leading-relaxed mt-0.5">
                      {COMPANY_INFO.address}
                    </p>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#1565C0]/10 text-[#1565C0] flex items-center justify-center flex-shrink-0">
                    <PhoneCall className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0B1F33]">Direct Engineering Line</h3>
                    <a
                      href={`tel:${COMPANY_INFO.phoneRaw}`}
                      className="text-[#1565C0] hover:underline font-bold text-sm block mt-0.5"
                    >
                      {COMPANY_INFO.phone}
                    </a>
                    <span className="text-[11px] text-slate-400">Available Mon–Sat during work hours</span>
                  </div>
                </div>

                {/* WhatsApp */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0B1F33]">WhatsApp Technical Desk</h3>
                    <a
                      href={COMPANY_INFO.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-700 hover:underline font-bold text-sm block mt-0.5"
                    >
                      +92 313 2513076
                    </a>
                    <span className="text-[11px] text-slate-400">Fast photo & drawing exchange</span>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#1565C0]/10 text-[#1565C0] flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0B1F33]">Official Emails</h3>
                    <a
                      href={`mailto:${COMPANY_INFO.email}`}
                      className="text-[#1565C0] hover:underline block font-medium mt-0.5"
                    >
                      {COMPANY_INFO.email}
                    </a>
                    <a
                      href={`mailto:${COMPANY_INFO.secondaryEmail}`}
                      className="text-[#667085] hover:underline block font-medium text-xs mt-0.5"
                    >
                      {COMPANY_INFO.secondaryEmail}
                    </a>
                  </div>
                </div>

                {/* Working Hours */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#1565C0]/10 text-[#1565C0] flex items-center justify-center flex-shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#0B1F33]">Operating Hours</h3>
                    <p className="text-[#667085] leading-relaxed mt-0.5">
                      {COMPANY_INFO.businessHours}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Map Directions Card */}
            <div className="bg-[#0B1F33] text-white p-6 rounded-xl border border-[#1565C0]/30 shadow-sm">
              <h3 className="text-sm font-bold text-[#38BDF8] uppercase tracking-wider mb-2">
                SITE Industrial Area Route
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Our manufacturing workshop is situated in Karachi's primary industrial zone (SITE Area), offering straightforward container truck access and proximity to the Port of Karachi for easy export or domestic transit.
              </p>
            </div>
          </div>

          {/* Right: Technical Inquiry Form (7 cols) */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-[#D9E1E8] p-6 sm:p-8 shadow-sm">
            <h2 className="text-xl font-bold text-[#0B1F33] mb-2">
              Send Direct Engineering Inquiry
            </h2>
            <p className="text-xs text-[#667085] mb-6">
              Fill in your manufacturing machine requirements. You can also click "Request a Quote" for our structured equipment quoting sheet.
            </p>

            {formSubmitted ? (
              <div className="p-8 text-center bg-emerald-50 rounded-lg border border-emerald-200">
                <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-[#0B1F33]">Message Sent Successfully!</h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto mt-2 mb-6">
                  Thank you for contacting TERAZ ENGINEERING. Our team in SITE Karachi will review your message and reply via phone or email shortly.
                </p>
                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={handleWhatsApp}
                    className="px-5 py-2.5 bg-emerald-600 text-white text-xs font-bold rounded-lg shadow-sm"
                  >
                    Open on WhatsApp Now
                  </button>
                  <button
                    onClick={() => setFormSubmitted(false)}
                    className="px-4 py-2 bg-white text-slate-700 text-xs font-semibold rounded-lg border border-slate-300"
                  >
                    Send Another
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Asif Khan"
                      className="w-full px-3.5 py-2 text-xs bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                      Company / Organization
                    </label>
                    <input
                      type="text"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      placeholder="e.g. Karachi Textiles Ltd"
                      className="w-full px-3.5 py-2 text-xs bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="name@domain.com"
                      className="w-full px-3.5 py-2 text-xs bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+92 300 0000000"
                      className="w-full px-3.5 py-2 text-xs bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Machinery Category / Subject *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="e.g. Ribbon Blender 1000L or Screw Conveyor 20ft"
                    className="w-full px-3.5 py-2 text-xs bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Detailed Requirements / Message *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Describe your processing material, capacity requirements, or factory layout..."
                    className="w-full px-3.5 py-2 text-xs bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => onRequestQuote()}
                    className="text-xs font-bold text-[#1565C0] hover:underline"
                  >
                    Need structured quotation with price breakdown? Click here
                  </button>

                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#1565C0] hover:bg-[#0B2A4A] text-white font-bold text-xs rounded-lg shadow-sm transition-colors"
                  >
                    <Send className="w-4 h-4" />
                    Submit Inquiry
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
