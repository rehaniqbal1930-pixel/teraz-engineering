import React from 'react';
import { Wrench, CheckCircle2, FileText, Settings, ShieldCheck, ArrowRight, Layers, Factory, MessageSquare } from 'lucide-react';
import { COMPANY_INFO } from '../data/products';

interface CustomEngineeringPageProps {
  onRequestQuote: (productName?: string) => void;
}

export const CustomEngineeringPage: React.FC<CustomEngineeringPageProps> = ({ onRequestQuote }) => {
  return (
    <div className="bg-[#F4F7FA] min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Banner */}
        <div className="bg-[#0B1F33] text-white rounded-2xl p-8 sm:p-12 mb-12 shadow-xl">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-widest text-[#38BDF8]">
              TAILORED PROCESS FABRICATION • KARACHI
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold mt-2 mb-4 text-white">
              Custom Machinery Engineering & Plant Fabrication
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Standard catalogue machines don't always fit your exact batch volumes, factory ceiling heights, or material flow rates. TERAZ ENGINEERING specializes in designing and building custom machinery from the ground up.
            </p>
          </div>
        </div>

        {/* 5-Step Custom Engineering Process */}
        <div className="bg-white rounded-xl border border-[#D9E1E8] p-8 shadow-sm mb-12">
          <div className="border-b border-[#D9E1E8] pb-4 mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
              OUR METHODOLOGY
            </span>
            <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
              How We Build Your Custom Machinery
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <div className="bg-[#F4F7FA] p-5 rounded-lg border border-[#D9E1E8]">
              <div className="w-8 h-8 rounded-full bg-[#1565C0] text-white font-bold flex items-center justify-center text-xs mb-3">
                01
              </div>
              <h3 className="text-sm font-bold text-[#0B1F33] mb-1">Process Scoping</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                Analysis of material physical traits: bulk density, moisture, corrosiveness, viscosity, and target hourly output.
              </p>
            </div>

            <div className="bg-[#F4F7FA] p-5 rounded-lg border border-[#D9E1E8]">
              <div className="w-8 h-8 rounded-full bg-[#1565C0] text-white font-bold flex items-center justify-center text-xs mb-3">
                02
              </div>
              <h3 className="text-sm font-bold text-[#0B1F33] mb-1">CAD Engineering</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                3D CAD modeling, shaft stress analysis, structural load calculations, and dimensional layout approval.
              </p>
            </div>

            <div className="bg-[#F4F7FA] p-5 rounded-lg border border-[#D9E1E8]">
              <div className="w-8 h-8 rounded-full bg-[#1565C0] text-white font-bold flex items-center justify-center text-xs mb-3">
                03
              </div>
              <h3 className="text-sm font-bold text-[#0B1F33] mb-1">Precision Fabrication</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                CNC plasma/laser cutting, sheet rolling, precision lathe shaft turning, and ASME standard sanitary TIG welding.
              </p>
            </div>

            <div className="bg-[#F4F7FA] p-5 rounded-lg border border-[#D9E1E8]">
              <div className="w-8 h-8 rounded-full bg-[#1565C0] text-white font-bold flex items-center justify-center text-xs mb-3">
                04
              </div>
              <h3 className="text-sm font-bold text-[#0B1F33] mb-1">Testing (FAT)</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                Comprehensive Factory Acceptance Testing (FAT) with dry running, vibration analysis, and motor temperature logging.
              </p>
            </div>

            <div className="bg-[#F4F7FA] p-5 rounded-lg border border-[#D9E1E8]">
              <div className="w-8 h-8 rounded-full bg-[#1565C0] text-white font-bold flex items-center justify-center text-xs mb-3">
                05
              </div>
              <h3 className="text-sm font-bold text-[#0B1F33] mb-1">Commissioning</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                Delivery to your mill or factory anywhere in Pakistan, complete on-site assembly, wiring, and operator training.
              </p>
            </div>
          </div>
        </div>

        {/* Custom Capabilities Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-xl border border-[#D9E1E8] p-8 shadow-sm">
            <h3 className="text-lg font-bold text-[#0B1F33] mb-4 flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#1565C0]" />
              Materials & Finishing Capabilities
            </h3>
            <div className="space-y-3 text-xs sm:text-sm text-[#1F2933]">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0] flex-shrink-0 mt-0.5" />
                <span><strong>Stainless Steel (AISI 304 / 316 / 316L):</strong> Sanitary finishes from 180 grit satin to mirror polish (Ra &lt; 0.4 µm).</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0] flex-shrink-0 mt-0.5" />
                <span><strong>Carbon & Mild Steel:</strong> Heavy structural frames, industrial blast-cleaned and coated with anti-corrosive epoxy enamels.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0] flex-shrink-0 mt-0.5" />
                <span><strong>Abrasion-Resistant Liners:</strong> Hardox and ultra-high-molecular-weight polyethylene (UHMWPE) wear liners for heavy aggregates.</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#D9E1E8] p-8 shadow-sm">
            <h3 className="text-lg font-bold text-[#0B1F33] mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5 text-[#1565C0]" />
              Electrical, Drive & Automation Capabilities
            </h3>
            <div className="space-y-3 text-xs sm:text-sm text-[#1F2933]">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0] flex-shrink-0 mt-0.5" />
                <span><strong>Motors & Reducers:</strong> Helical-bevel gearmotors, explosion-proof motors for chemical zones, dual-speed motors.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0] flex-shrink-0 mt-0.5" />
                <span><strong>VFD & Speed Control:</strong> Digital variable speed controllers for fine recipe tuning and soft starts.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#1565C0] flex-shrink-0 mt-0.5" />
                <span><strong>Pneumatics & Automation:</strong> Automated slide gates, load cell batching integration, PLC touchscreen interfaces.</span>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Bar */}
        <div className="bg-[#17212B] rounded-xl text-white p-8 text-center border border-slate-700">
          <h2 className="text-2xl font-bold mb-2">Have a Custom Machinery Drawing or Idea?</h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto mb-6">
            Share your sketch, CAD drawing, or process description with our Karachi team for an initial engineering review and pricing estimate.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onRequestQuote('Custom Plant Engineering')}
              className="px-6 py-3 bg-[#1565C0] hover:bg-[#2196F3] text-white font-bold text-xs rounded-lg transition-colors shadow-md"
            >
              Request Custom Engineering Quote
            </button>
            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-2 shadow-md"
            >
              <MessageSquare className="w-4 h-4" />
              Discuss on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
