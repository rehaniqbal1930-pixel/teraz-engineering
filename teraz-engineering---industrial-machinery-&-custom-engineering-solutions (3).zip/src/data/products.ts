import { Product } from '../types';

// Main image imports from generated high-resolution industrial photography
import ribbonMixerImg from '../assets/images/ribbon_mixer_main_1790094429782.jpg';
import screwConveyorImg from '../assets/images/screw_conveyor_main_1790094449007.jpg';
import bucketConveyorImg from '../assets/images/bucket_conveyor_main_1790094461589.jpg';
import beltConveyorImg from '../assets/images/belt_conveyor_main_1790094473076.jpg';
import rollerConveyorImg from '../assets/images/roller_conveyor_main_1790094488968.jpg';
import inclinedConveyorImg from '../assets/images/inclined_conveyor_main_1790094505246.jpg';
import fabricRewinderImg from '../assets/images/fabric_rewinder_main_1790094517931.jpg';
import fabricInspectionImg from '../assets/images/fabric_inspection_main_1790094530394.jpg';
import hopperTankImg from '../assets/images/hopper_tank_main_1790094547132.jpg';
import sifterVibratorImg from '../assets/images/sifter_vibrator_main_1790094560784.jpg';
import hammerMillImg from '../assets/images/hammer_mill_main_1790094576117.jpg';
import continuousFryerImg from '../assets/images/continuous_fryer_main_1790094589391.jpg';
import vegWasherImg from '../assets/images/veg_washer_main_1790094607437.jpg';
import customFabImg from '../assets/images/custom_fab_main_1790094620689.jpg';

export const PRODUCTS: Product[] = [
  {
    id: 'prod-ribbon-mixer',
    name: 'Industrial Stainless Steel Ribbon Mixer (Ribbon Blender)',
    slug: 'ribbon-mixer',
    category: 'Mixing & Blending Equipment',
    shortDescription: 'Heavy-duty industrial ribbon blender engineered for gentle, highly homogeneous mixing of dry powders, granules, seasonings, and bulk materials with sanitary stainless steel contact parts.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Ribbon Mixer (also known as an Industrial Ribbon Blender) is a high-efficiency convective mixing machine engineered for solid-solid and solid-liquid dry batch blending. Fabricated in Karachi using certified AISI 304 or 316 stainless steel, it provides rapid, uniform dispersion across bulk solids without thermal degradation.',
      whatDoesItDo: 'It blends dry powders, pharmaceutical ingredients, spices, food seasonings, chemical formulations, polymers, and mineral compounds into perfectly homogeneous mixtures. The counter-directional inner and outer helical ribbons ensure that material particles are continuously mobilized from both ends toward the center and from the center outward.',
      howItWorks: 'The machine consists of a horizontal U-shaped trough housing a precision-balanced central shaft with double helical ribbon agitators. As the heavy-duty electric motor rotates the rotor shaft through a helical bevel gearbox, the outer ribbon moves material from the trough ends inward toward the center discharge port. Simultaneously, the inner ribbon moves materials from the center outward to the ends. This generates three-dimensional convective fluidization and shear that thoroughly interlocks particles within minutes.',
      whereItIsUsed: 'Widely utilized in commercial food processing facilities, spice and flour mills, pharmaceutical excipient compounding plants, chemical manufacturing facilities, detergent blending lines, and polymer compounding workshops across Pakistan and overseas.',
      productionBenefits: 'Delivers high coefficient of variation (CV < 5%) blending uniformity, short batch cycle times, minimal residual hold-up at the sanitary bottom discharge valve, low operating maintenance costs, and exceptional mechanical longevity.',
      customEngineeringNote: 'TERAZ ENGINEERING customizes each ribbon blender to client batch volume (from 50 Liters up to 5,000 Liters), liquid spray manifold injection ports for oil or flavor addition, heating or cooling jackets, pneumatic discharge flap valves, and explosion-proof (FLP) motor systems.'
    },
    mainImage: ribbonMixerImg,
    galleryImages: [
      {
        url: ribbonMixerImg,
        alt: 'TERAZ ENGINEERING stainless steel industrial ribbon mixer main assembly in clean workshop',
        caption: 'Full horizontal assembly with heavy-duty structural steel frame and reduction drive'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'TERAZ ENGINEERING double helical ribbon agitator shaft close-up inside stainless steel trough',
        caption: 'Precision-balanced dual helical ribbon agitators for homogeneous bulk powder blending'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Sanitary TIG welding and polished metal surfaces on ribbon blender discharge valve',
        caption: 'Sanitary internal polish with radius corners to eliminate dead zones and powder retention'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Heavy-duty electric gear motor drive and industrial safety interlock guard on ribbon mixer',
        caption: 'Industrial electric motor and safety interlocked top grid hatch'
      }
    ],
    specifications: {
      machineType: 'Horizontal Double Helical Ribbon Blender',
      model: 'TE-RB Series (50L to 5000L)',
      capacity: '100 kg to 3,000 kg per batch (Customizable)',
      material: 'SS 304, SS 316 / Contact Parts, Mild Steel Subframe',
      construction: 'Heavy-gauge reinforced U-trough with continuous sanitary welds',
      motor: 'Siemens / ABB / Equivalent Industrial Grade TEFC Motor',
      motorPower: '5.5 kW to 30 kW (Depending on batch capacity & bulk density)',
      rpm: '24 to 45 RPM (Optimized for powder shear without dust explosion)',
      dimensions: 'Customized as per workshop floor layout',
      driveSystem: 'Heavy-duty helical bevel gearbox with flexible coupling',
      controlSystem: 'Manual On/Off panel or PLC Touchscreen with cycle timer and reverse jog',
      contactParts: 'Stainless Steel AISI 304 / AISI 316 (Food / Pharma Grade)',
      surfaceFinish: 'Internal 240-grit sanitary mirror polish, external glass bead blast or matte',
      inlet: 'Top charging hopper with dust protection safety grill and bag dump hood',
      outlet: 'Pneumatic / Manual center discharge butterfly or slide flap valve',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Semi-automatic or fully integrated PLC batch automation',
      optionalFeatures: 'Liquid spray nozzles, steam/water thermal jacket, load cells for loss-in-weight'
    },
    features: [
      'Heavy-Duty Fabrication with thick-gauge stainless steel plates for vibration-free duty',
      'Dual-Direction Helical Ribbons ensuring fast, homogeneous mixing within 4 to 8 minutes',
      'Sanitary Ground Welds with radiused internal corners preventing batch cross-contamination',
      'Air-Purged Gland Packing Seals on main shaft preventing powder leakage into bearings',
      'Safety Grid with Limit Switch cutting motor power instantly upon lid opening',
      'Center Bottom Discharge for rapid emptying with minimal residue hold-up',
      'Direct-Coupled Heavy Gearbox eliminating belt slippage and high maintenance costs'
    ],
    applications: [
      {
        title: 'Spices & Dry Seasonings',
        description: 'Blending chili powder, turmeric, garam masala, snack seasoning salts, and premixes without oil segregation.'
      },
      {
        title: 'Flour, Bakery & Confectionery Premixes',
        description: 'Uniform incorporation of leavening agents, starch, cocoa, emulsifiers, and powdered milk.'
      },
      {
        title: 'Pharmaceutical & Nutraceutical Powders',
        description: 'Sanitary blending of bulk excipients, active vitamins, proteins, and herbal formulations.'
      },
      {
        title: 'Chemical & Detergent Formulations',
        description: 'Mixing washing powders, agricultural fertilizers, pigments, cement additives, and lime blends.'
      }
    ],
    industries: [
      'Food Processing',
      'Pharmaceutical & Healthcare',
      'Chemical & Agro-Chemical',
      'Cosmetics & Detergents',
      'Plastics & Masterbatch'
    ],
    benefits: [
      {
        title: 'High Homogeneity & Consistency',
        description: 'Achieves uniform dispersion across ingredients with diverse particle sizes and bulk densities.'
      },
      {
        title: 'Durable Stainless Steel Construction',
        description: 'Resistant to corrosion from acidic spices, salts, and chemical cleaning agents.'
      },
      {
        title: 'Low Power Consumption',
        description: 'Optimized ribbon pitch and flight clearances deliver high material turnover with minimal power draw.'
      },
      {
        title: 'Fast Cleaning & Batch Turnaround',
        description: 'Full-length hinged top covers and sanitary flush valves allow fast washdowns between recipe changes.'
      }
    ],
    customizationOptions: [
      'Trough batch capacity tailored from small pilot 50L to large-scale 5,000L plants',
      'AISI 316L contact parts for pharmaceutical and highly saline food recipes',
      'Double-walled jacket for heating with steam/thermal oil or cooling with chilled water',
      'High-speed intensifier chopper blades for agglomerate breakdown and liquid dispersion',
      'Pneumatically actuated discharge gate linked to packing machines or downstream conveyors'
    ],
    relatedProductSlugs: ['screw-conveyor', 'bucket-conveyor', 'industrial-hoppers-tanks', 'sifter-vibrator']
  },

  {
    id: 'prod-screw-conveyor',
    name: 'Industrial Heavy-Duty Screw Conveyor (Auger Feeder)',
    slug: 'screw-conveyor',
    category: 'Material Handling & Conveying',
    shortDescription: 'Precision tubular and U-trough stainless steel screw conveyors for continuous, dust-free transfer of bulk powders, grains, granules, and dry raw materials across industrial production lines.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Screw Conveyor is an industrial bulk material handling machine engineered for reliable, enclosed transfer of powders, dry solids, and semi-moist materials. Available in enclosed tubular configurations or accessible U-trough styles, it provides dust-tight conveyance at horizontal or inclined elevations.',
      whatDoesItDo: 'It conveys bulk raw materials—such as wheat, flour, spices, salt, chemical pellets, cement, and plastic regrind—from storage hoppers, grinders, or blenders into downstream processing equipment, packaging silos, or mixers in continuous, regulated quantities.',
      howItWorks: 'A rotating helical screw flight welded to a central structural steel pipe turns inside a stationary casing. As the drive motor rotates the auger, material pushed by the advancing spiral moves along the trough bottom in an axial direction. The enclosed housing prevents environmental contamination and stops hazardous process dust from escaping into the facility.',
      whereItIsUsed: 'Essential in grain processing facilities, spice processing lines, chemical plants, snack manufacturing, fertilizer factories, plastics recycling facilities, and packaging automation systems throughout Pakistan.',
      productionBenefits: 'Eliminates manual hauling, minimizes operator exposure to dust, provides accurate volumetric metering, and occupies minimal floor area compared to open conveyor systems.',
      customEngineeringNote: 'TERAZ ENGINEERING custom-builds screw conveyors to your required transfer distance (from 2 meters up to 25 meters), flight diameter (100mm to 500mm), variable pitch for uniform hopper extraction, cantilevered center-shaftless designs, and quick-release sanitary cleanout doors.'
    },
    mainImage: screwConveyorImg,
    galleryImages: [
      {
        url: screwConveyorImg,
        alt: 'TERAZ ENGINEERING stainless steel tubular screw conveyor auger feeder in workshop',
        caption: 'Enclosed sanitary tubular screw conveyor with direct-drive geared motor'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Stainless steel continuous helical screw auger flight fabrication and welding',
        caption: 'Continuous helicoid flight auger welded to heavy central pipe'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Inlet charging hopper and quick-clamp cleanout hatch on screw conveyor',
        caption: 'Sanitary inlet adapter designed for direct coupling beneath blenders or silos'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Flanged intermediate bearing and rugged electric motor drive assembly',
        caption: 'Heavy-duty outboard sealed bearing assembly keeping lubricant away from product'
      }
    ],
    specifications: {
      machineType: 'Industrial Screw Conveyor / Auger Elevator',
      model: 'TE-SC Series (Tubular / U-Trough)',
      capacity: '500 kg/hr up to 25,000 kg/hr (Engineered to requirements)',
      material: 'SS 304, SS 316, or Heavy-Duty Carbon Steel',
      construction: 'Continuous welded flighting, seamless casing, reinforced support saddles',
      motor: 'High-torque TEFC Geared Motor with thermal protection',
      motorPower: '1.5 kW to 15 kW (Calculated based on material bulk density & lift height)',
      rpm: '30 to 120 RPM (Variable speed available via VFD)',
      dimensions: 'Diameter: 100mm to 500mm; Length: 1.5m to 25m',
      driveSystem: 'Direct hollow-shaft gearmotor or chain & sprocket drive',
      controlSystem: 'Direct On-Line Starter or Variable Frequency Drive (VFD) for metering',
      contactParts: 'AISI 304 / 316 Stainless Steel or Hardox abrasion-resistant steel',
      surfaceFinish: 'Food-grade bead blasted or industrial epoxy painted casing',
      inlet: 'Square / Round flanged inlet with optional bag breaker hopper',
      outlet: 'Drop-down discharge spout with manual or pneumatic slide gate',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Level sensor interlocks with automatic start/stop signals',
      optionalFeatures: 'Mobile caster wheel trolley, reverse cleanout switch, water flush port'
    },
    features: [
      'Dust-Free Fully Enclosed Design preventing product contamination and airborne particulate release',
      'Heavy Helicoid / Segmental Flights designed for continuous abrasive duty without deflection',
      'External Outboard Bearing Housings isolating bearings and seals from the material flow stream',
      'Flexible Incline Capability operating efficiently from horizontal (0°) up to steep inclines (60°)',
      'Quick-Opening Bottom Cleanout Panels allowing rapid sanitization during product changeovers',
      'Direct-Coupled Helical Geared Motor offering high torque and energy efficiency'
    ],
    applications: [
      {
        title: 'Bulk Powder Feeding',
        description: 'Feeding flour, starch, milk powder, salt, and spices directly into blenders or packaging lines.'
      },
      {
        title: 'Grinder & Mill Discharge',
        description: 'Receiving freshly ground grains, seeds, or spices from hammer mills and conveying to holding silos.'
      },
      {
        title: 'Chemical & Mineral Handling',
        description: 'Moving calcium carbonate, carbon black, plastic granules, and dry fertilizer blends safely.'
      },
      {
        title: 'Sludge & Waste Management',
        description: 'Shaftless screw variants for conveying wet dewatered cake and organic industrial waste.'
      }
    ],
    industries: [
      'Food & Beverage Processing',
      'Flour & Rice Mills',
      'Pharmaceutical Compounding',
      'Chemical & Fertilizer',
      'Plastics & Recycling'
    ],
    benefits: [
      {
        title: 'Total Process Containment',
        description: 'Keeps fine powders contained, preserving clean air standards inside the workshop.'
      },
      {
        title: 'Accurate Dosing & Feeding',
        description: 'Can be linked to variable speed drives to function as a precision continuous gravimetric feeder.'
      },
      {
        title: 'Compact Footprint',
        description: 'Requires significantly less space than open belt conveyors, especially on elevated transfer runs.'
      },
      {
        title: 'Low Maintenance Downtime',
        description: 'No belt alignment or tracking issues; robust mechanical transmission designed for 24/7 reliability.'
      }
    ],
    customizationOptions: [
      'Custom inlet hopper with integrated bag split table and dust hood',
      'Shaftless screw design for sticky, fibrous, or moisture-laden materials',
      'Variable Frequency Drive (VFD) for continuous volumetric dosing into mixers',
      'Mobile wheeled frame with height-adjustable hand winch for multi-station feeding',
      'Double-jacketed casing for material heating, cooling, or drying during conveyance'
    ],
    relatedProductSlugs: ['ribbon-mixer', 'bucket-conveyor', 'industrial-hoppers-tanks', 'hammer-mill-pulverizer']
  },

  {
    id: 'prod-bucket-conveyor',
    name: 'Industrial Vertical Bucket Elevator Conveyor',
    slug: 'bucket-conveyor',
    category: 'Material Handling & Conveying',
    shortDescription: 'High-capacity vertical continuous bucket elevator designed for space-efficient vertical transport of free-flowing grains, seeds, granules, coffee, and bulk minerals.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Bucket Elevator Conveyor is an industrial vertical material lift engineered to elevate free-flowing dry solids and bulk materials to significant heights with minimum floor footprint. Built with heavy-gauge sheet steel and precision belt or chain drive systems, it provides reliable vertical logistics.',
      whatDoesItDo: 'It transports bulk materials vertically from ground-level intake pits or discharge hoppers up to overhead silos, storage bins, screening separators, packaging weighers, or processing decks without spillage or product degradation.',
      howItWorks: 'A series of food-grade nylon, polyurethane, or pressed steel buckets are bolted at regular intervals to a heavy-duty continuous rubber belt or steel link chain. At the bottom boot section, material is fed into the casing where buckets scoop up the product. The buckets travel vertically through the dust-tight trunking to the top head section, where centrifugal force or gravity discharges the material smoothly into the delivery chute.',
      whereItIsUsed: 'Vital in grain silos, seed cleaning plants, animal feed mills, rice processing lines, confectionery factories, detergent plants, and chemical processing facilities across Karachi and nationwide.',
      productionBenefits: 'Occupies the absolute smallest floor area for vertical elevation, features low energy consumption per ton of elevated material, and protects fragile goods against degradation.',
      customEngineeringNote: 'TERAZ ENGINEERING engineers continuous bucket elevators (Z-type, C-type, or straight vertical) with tailored discharge heights (up to 30 meters), food-safe sanitary belts, variable bucket capacities, explosion relief vents, and inspection windows.'
    },
    mainImage: bucketConveyorImg,
    galleryImages: [
      {
        url: bucketConveyorImg,
        alt: 'TERAZ ENGINEERING vertical industrial bucket elevator casing and drive head',
        caption: 'Enclosed heavy-duty vertical bucket elevator casing with safety maintenance access'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Internal food-grade polymer buckets mounted on heavy-duty traction belt',
        caption: 'Food-safe injection molded buckets mounted on reinforced multi-ply belt'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Bottom boot tensioning section with screw take-up and cleanout slide gate',
        caption: 'Precision screw take-up mechanism for optimal belt tensioning'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Head drive gearbox with backstop mechanism preventing reverse rotation',
        caption: 'Top drive head equipped with integrated mechanical backstop clutch'
      }
    ],
    specifications: {
      machineType: 'Vertical Bucket Elevator (Centrifugal / Continuous Discharge)',
      model: 'TE-BE Series',
      capacity: '2 to 50 Tons per hour (Engineered to client specification)',
      material: 'AISI 304 Stainless Steel or Structural Carbon Steel',
      construction: 'Self-supporting modular casing sections with dust-proof flanged joints',
      motor: 'TEFC Industrial Geared Motor with integrated brake or backstop',
      motorPower: '2.2 kW to 22 kW (Height and volume matched)',
      rpm: 'Head pulley optimized for clean discharge without kernel fracture',
      dimensions: 'Discharge Heights from 3 meters up to 30 meters',
      driveSystem: 'Direct shaft-mounted helical gear reducer with torque arm',
      controlSystem: 'Standard control cabinet with belt slip detector and speed sensor',
      contactParts: 'Food-grade Polyethylene (HDPE), Nylon, or SS 304 Pressed Buckets',
      surfaceFinish: 'Industrial powder coating or mirror stainless finish',
      inlet: 'Feed intake hopper with adjustable flow slide gate at boot',
      outlet: 'Lined wear-resistant discharge chute angled for high-velocity transfer',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Zero-speed switch, belt misalignment sensors, and overload cutoffs',
      optionalFeatures: 'Explosion relief vents, service access platform with caged ladder'
    },
    features: [
      'Space-Optimized Vertical Footprint lifting materials up to 30m without taking valuable floor space',
      'Dust-Tight Modular Casing maintaining clean ambient plant conditions without powder leakage',
      'Anti-Reverse Backstop Clutch preventing elevator rollback during sudden power interruptions',
      'Heavy-Duty Screw Take-Up at boot for simple, accurate belt alignment and tension maintenance',
      'Removable Inspection Hatches at head, leg, and boot sections for rapid maintenance access',
      'Wear-Resistant Buckets available in HDPE, nylon, polyurethane, or pressed stainless steel'
    ],
    applications: [
      {
        title: 'Grains & Pulses Processing',
        description: 'Lifting wheat, rice, corn, lentils, and barley into cleaners, dryers, and storage silos.'
      },
      {
        title: 'Snack Foods & Confectionery',
        description: 'Elevating extruded pellets, snacks, roasted nuts, candies, and dried fruits to weighers.'
      },
      {
        title: 'Fertilizer & Chemical Granules',
        description: 'Vertical transfer of urea prills, compound fertilizers, plastic resins, and mineral sands.'
      },
      {
        title: 'Coffee Beans & Tea Packaging',
        description: 'Gentle vertical lift of roasted or green coffee beans to multi-head packaging weighers.'
      }
    ],
    industries: [
      'Grain & Agriculture',
      'Food & Snack Processing',
      'Animal Feed Manufacturing',
      'Chemical & Fertilizer',
      'Packaging & Warehousing'
    ],
    benefits: [
      {
        title: 'Maximum Height, Minimal Ground Footprint',
        description: 'Replaces long inclined conveyors that would otherwise consume dozens of meters of floor space.'
      },
      {
        title: 'Low Operating Energy Draw',
        description: 'High mechanical efficiency lifts heavy bulk tonnages with small, economical electric motors.'
      },
      {
        title: 'Gentle Product Handling',
        description: 'Continuous bucket overlap designs eliminate drop shock for breakable snacks and grains.'
      },
      {
        title: 'Long Service Life',
        description: 'Fabricated with rigid structural stiffeners and high-grade anti-abrasion components.'
      }
    ],
    customizationOptions: [
      'Z-Type and C-Type multi-axis configurations for simultaneous horizontal and vertical routing',
      'Specialized food-grade white FDA rubber belts or stainless steel elevator link chains',
      'Pneumatic cleanout trapdoor at the boot for comprehensive sanitization between grains',
      'Exterior galvanized finish for open-air yard installations or coastal marine environments'
    ],
    relatedProductSlugs: ['ribbon-mixer', 'screw-conveyor', 'belt-conveyor', 'sifter-vibrator']
  },

  {
    id: 'prod-belt-conveyor',
    name: 'Industrial Heavy-Duty Belt Conveyor System',
    slug: 'belt-conveyor',
    category: 'Material Handling & Conveying',
    shortDescription: 'Industrial-grade continuous belt conveyors engineered for flat and horizontal transportation of packaged goods, cartons, bags, bulk materials, and assembly parts.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Industrial Belt Conveyor is a versatile material handling system designed for the smooth, continuous horizontal movement of unit loads, packed goods, and bulk materials across factory floors.',
      whatDoesItDo: 'It connects processing stations, packing machines, metal detectors, sorting tables, and warehouse loading docks into a seamless, high-speed automated workflow.',
      howItWorks: 'A continuous endless loop of high-tensile multi-ply conveyor belt rides over a structural steel slider bed or precision idling rollers. Driven by an electric motorized pulley or shaft-mounted gearmotor, the belt carries products smoothly without vibration or product shift.',
      whereItIsUsed: 'Extensively applied across packaging departments, warehouse logistics centers, food processing assembly lines, textile garment sorting facilities, and general industrial manufacturing plants in Pakistan.',
      productionBenefits: 'Drastically cuts manual material handling labor, accelerates unit production throughput, prevents carton and packaging damage, and improves factory ergonomics.',
      customEngineeringNote: 'Available with food-grade white PVC/PU belts, rubber belts for heavy duty boxes, stainless steel frames for sanitary washdown, adjustable side guide rails, and variable speed drive controls.'
    },
    mainImage: beltConveyorImg,
    galleryImages: [
      {
        url: beltConveyorImg,
        alt: 'TERAZ ENGINEERING heavy-duty flat industrial belt conveyor system with structural frame',
        caption: 'Full conveyor frame showing motorized drive section, slider bed, and support legs'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'High-tensile multi-ply conveyor belt with precision crowned drive pulley',
        caption: 'Machined crowned drive pulley ensuring accurate belt tracking under continuous load'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Adjustable stainless steel side guide rails and emergency pull-cord stop switch',
        caption: 'Integrated safety features including emergency stop pull wire and protective skirting'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Variable frequency drive controller cabinet mounted to conveyor leg',
        caption: 'Compact VFD control panel allowing speed synchronization with packing lines'
      }
    ],
    specifications: {
      machineType: 'Horizontal / Slider Bed Belt Conveyor',
      model: 'TE-BC Series',
      capacity: 'Up to 250 kg per linear meter (Customizable to load profile)',
      material: 'AISI 304 Stainless Steel or Powder-Coated Mild Steel',
      construction: 'Modular formed channel frame with welded cross-tie stiffeners',
      motor: 'European / Asian Standard High-Efficiency Geared Motor',
      motorPower: '0.75 kW to 7.5 kW',
      rpm: 'Belt speed adjustable from 5 to 45 meters/minute',
      dimensions: 'Width: 300mm to 1500mm; Length: 2m to 50m (Modular sections)',
      driveSystem: 'Head drive, center drive, or motorized drum pulley',
      controlSystem: 'VFD Speed Controller with forward/reverse and photo-eye indexing',
      contactParts: 'FDA Approved White PVC, Anti-Static Green PVC, or Heat-Resistant Rubber',
      surfaceFinish: 'Sanitary bead blast or industrial polyurethane industrial enamel',
      inlet: 'Feed transition chute or manual loading work deck',
      outlet: 'Roller transfer bridge or gravity discharge roller slide',
      powerSupply: '220V Single Phase or 380V - 415V 3 Phase',
      automation: 'Photoelectric sensors, pneumatic diverter arms, barcode reader mounting',
      optionalFeatures: 'Lockable swivel casters, overhead task lighting, operator packing tables'
    },
    features: [
      'Modular Channel Frame allowing rapid line reconfiguration and future length extensions',
      'Precision Crowned Pulleys coated with rubber lagging for positive belt traction',
      'Quick-Adjust Screw Tensioners making belt tracking simple for factory operators',
      'Adjustable Height Legs with leveling feet compensating for uneven industrial floors',
      'Comprehensive Safety Guards covering pinch points, pulleys, and drive mechanisms'
    ],
    applications: [
      {
        title: 'Packaging & End-of-Line Boxing',
        description: 'Transporting cartons through automatic strapping, taping, and labeling systems.'
      },
      {
        title: 'Assembly & Inspection Lines',
        description: 'Providing smooth continuous work surfaces for electronic, automotive, and appliance assembly.'
      },
      {
        title: 'Warehouse Order Fulfillment',
        description: 'Connecting pick-and-pack stations to shipping docks with zero carton damage.'
      }
    ],
    industries: [
      'Food & Beverage Packaging',
      'Pharmaceutical Manufacturing',
      'Textile & Garment Logistics',
      'E-commerce & Warehousing',
      'General Manufacturing'
    ],
    benefits: [
      {
        title: 'Smooth, Vibration-Free Transfer',
        description: 'Protects delicate bottles, cartons, and unpacked foods from tipping or scuffing.'
      },
      {
        title: 'Quiet Plant Operation',
        description: 'Low mechanical decibel levels create comfortable workshop conditions.'
      },
      {
        title: 'Low Power Consumption',
        description: 'Minimal friction engineering saves electricity during long continuous shifts.'
      }
    ],
    customizationOptions: [
      'Integration of side work tables for manual packagers',
      'Pneumatic pushers and sorting gates for automated line diversion',
      'Stainless steel washdown grade for seafood, poultry, and dairy plants'
    ],
    relatedProductSlugs: ['roller-conveyor', 'inclined-conveyor', 'screw-conveyor', 'bucket-conveyor']
  },

  {
    id: 'prod-roller-conveyor',
    name: 'Heavy-Duty Gravity & Motorized Roller Conveyor',
    slug: 'roller-conveyor',
    category: 'Material Handling & Conveying',
    shortDescription: 'Robust gravity and motorized live roller conveyors designed for smooth transportation, accumulation, and sorting of heavy cartons, crates, pallets, and drums.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Heavy-Duty Roller Conveyor is an industrial material transfer line utilizing precision steel rollers mounted in reinforced side frames. Engineered in both gravity (unpowered) and motorized live roller (driven) formats, it handles heavy unit loads reliably.',
      whatDoesItDo: 'It moves rigid-bottom loads—including corrugated boxes, plastic crates, wooden pallets, steel drums, and manufacturing dies—between machinery, packing stations, and warehouse storage bays.',
      howItWorks: 'A series of precision steel rollers equipped with commercial or semi-precision ball bearings rotate on solid hexagonal or round axles. In gravity systems, a slight declination angle (1.5° to 3°) allows items to roll by gravity. In motorized systems, rollers are powered by an electric motor via line shaft, tangential chain, or motorized roller cartridges.',
      whereItIsUsed: 'Heavy manufacturing plants, beverage bottling depots, textile fabric roll storage, cold storage warehouses, and airport cargo facilities across Pakistan.',
      productionBenefits: 'Zero energy cost for gravity variants, heavy weight bearing capacity (up to 1,500 kg per meter), rugged durability against impact, and zero maintenance friction.',
      customEngineeringNote: 'TERAZ ENGINEERING manufactures roller diameters from 38mm to 89mm, galvanized or stainless steel rollers, rubber-sleeved rollers for delicate surfaces, curved 90°/180° sections, and pneumatic pallet stops.'
    },
    mainImage: rollerConveyorImg,
    galleryImages: [
      {
        url: rollerConveyorImg,
        alt: 'TERAZ ENGINEERING heavy-duty motorized industrial roller conveyor line',
        caption: 'Heavy-duty motorized roller conveyor featuring precision galvanized rollers and steel chassis'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Close-up of galvanized steel rollers with low-noise sealed precision bearings',
        caption: 'Galvanized precision rollers with dual sealed bearings for quiet high-load operation'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Curved 90-degree tapered roller conveyor junction module',
        caption: 'Curved tapered roller assembly maintaining package orientation around corners'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Pneumatic blade package stop and optical sensors for zero pressure accumulation',
        caption: 'Zero-pressure accumulation zone preventing carton crushing during buffer queues'
      }
    ],
    specifications: {
      machineType: 'Gravity / Driven Live Roller Conveyor',
      model: 'TE-RC Series',
      capacity: '50 kg to 1,500 kg per meter (Light to Pallet Class)',
      material: 'Galvanized Steel, AISI 304 Stainless Steel, or PVC Rollers',
      construction: 'Laser-cut channel frames with reinforced structural tubular cross members',
      motor: 'Chain-driven gearmotor or 24V DC motorized drive rollers (MDR)',
      motorPower: '0.37 kW to 5.5 kW (When motorized)',
      rpm: 'Constant or variable roller speed up to 30 m/min',
      dimensions: 'Width: 300mm to 1200mm; Length: 1m modular units up to 100m lines',
      driveSystem: 'Duplex roller chain, poly-V band, or gravity decline',
      controlSystem: 'Integrated photo-eye zero-pressure accumulation (ZPA) logic',
      contactParts: 'Zinc-plated carbon steel, stainless steel, or polyurethane coating',
      surfaceFinish: 'Electro-galvanized rollers with epoxy powder coated frame',
      inlet: 'Entry impact plate or feed alignment guides',
      outlet: 'End stop brake, pop-up transfer, or gravity skatewheel run-off',
      powerSupply: '220V / 380V / 415V 50Hz',
      automation: 'Zone-based automatic start/stop and pneumatic divert gates',
      optionalFeatures: 'Forklift-accessible pop-up pallet turntables, ball transfer tables'
    },
    features: [
      'Heavy Load Capacity supporting stacked crates, heavy machinery components, and pallets',
      'Low Friction Bearings allowing effortless movement even under heavy manual push forces',
      'Modular Bolt-Together Design for easy installation, future expansion, or facility relocation',
      'Tapered Roller Curves maintaining load alignment and preventing jams around bends',
      'Zero Pressure Accumulation (ZPA) stopping boxes behind one another without impact'
    ],
    applications: [
      {
        title: 'Pallet Handling & Storage',
        description: 'Feeding loaded pallets into stretch wrappers, cold rooms, and shipping docks.'
      },
      {
        title: 'Textile Fabric Roll Transfer',
        description: 'Moving heavy raw and dyed textile rolls between batching machines and inspection.'
      },
      {
        title: 'Beverage Crate Accumulation',
        description: 'Holding buffer queues of bottled crates between filling and palletizing stations.'
      }
    ],
    industries: [
      'Beverage & Bottling',
      'Textile & Weaving Mills',
      'Warehouse Logistics & 3PL',
      'Automotive Parts Assembly',
      'Chemical & Drum Handling'
    ],
    benefits: [
      {
        title: 'Extreme Mechanical Longevity',
        description: 'Hardened steel rollers withstand drops, high impact, and rugged shopfloor abuse.'
      },
      {
        title: 'Cost-Effective Material Flow',
        description: 'Gravity sections operate with 0% electricity cost, slashing utility expenses.'
      },
      {
        title: 'Flexible Factory Configuration',
        description: 'Can be configured straight, curved, inclined, or merged to suit any workshop layout.'
      }
    ],
    customizationOptions: [
      'Pneumatic pop-up chain transfers for right-angle direction changes',
      'Integrated load-cell scale sections for weighing boxes while in motion',
      'Heavy-duty castors for mobile staging conveyors'
    ],
    relatedProductSlugs: ['belt-conveyor', 'inclined-conveyor', 'fabric-rewinder', 'custom-machinery-fabrication']
  },

  {
    id: 'prod-inclined-conveyor',
    name: 'Inclined Cleated & Chevron Belt Conveyor',
    slug: 'inclined-conveyor',
    category: 'Material Handling & Conveying',
    shortDescription: 'Heavy-duty inclined belt conveyors equipped with molded rubber cleats, chevrons, and corrugated sidewalls for elevating bags, boxes, loose grain, and bulk products up steep angles.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Inclined Conveyor is a specialized elevation system equipped with cleated or chevron patterned belts designed to lift loose materials or packaged goods up slopes from 15° to 60° without slippage or roll-back.',
      whatDoesItDo: 'It transfers goods between different factory levels—such as lifting bags from sewing lines into transport trucks, or lifting loose vegetables, chips, or chemical granules into elevated storage hoppers.',
      howItWorks: 'The conveyor uses a belt molded with transverse cross cleats or V-shaped chevron profiles. As the drive unit pulls the belt up the angled chassis, the cleats act as physical barriers that trap material pockets, preventing gravity from rolling items downward.',
      whereItIsUsed: 'Loading docks, agricultural bag stitching units, snack food packaging lines, seed cleaning plants, and recycling facilities across Pakistan.',
      productionBenefits: 'Eliminates back-breaking manual loading of 50kg bags into trucks, connects ground-floor processes to mezzanine floors, and operates reliably in dusty conditions.',
      customEngineeringNote: 'TERAZ ENGINEERING manufactures mobile inclined conveyors with manual hydraulic or screw jacks for adjustable discharge heights, reversible drive motors, and tow hitches for truck loading.'
    },
    mainImage: inclinedConveyorImg,
    galleryImages: [
      {
        url: inclinedConveyorImg,
        alt: 'TERAZ ENGINEERING inclined cleated chevron belt conveyor on adjustable wheel chassis',
        caption: 'Heavy-duty inclined cleated conveyor with adjustable elevation jack and mobile wheels'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'High-profile molded rubber cleats and corrugated sidewall details on inclined belt',
        caption: 'Corrugated rubber sidewall belt preventing product spillage during steep vertical ascents'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Bottom loading hopper section with rubber skirt seals',
        caption: 'Impact-absorbing feed hopper ensuring centered loading on the cleated belt'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Electric motorized reduction drive and backstop assembly',
        caption: 'High-torque geared motor with anti-rollback safety brake'
      }
    ],
    specifications: {
      machineType: 'Inclined Cleated / Chevron Belt Conveyor',
      model: 'TE-IC Series',
      capacity: 'Up to 60 Tons/hour bulk or 600 bags/hour (50kg bags)',
      material: 'Structural Steel with Anti-Corrosion Coating or AISI 304 Stainless Steel',
      construction: 'Lattice girder or heavy folded channel frame with hydraulic angle adjustment',
      motor: 'TEFC Flange-Mounted Geared Motor with Fail-Safe Brake',
      motorPower: '1.5 kW to 11 kW',
      rpm: 'Belt speed 15 to 40 meters per minute',
      dimensions: 'Belt width: 400mm to 1000mm; Incline length: 4m to 18m; Angle: 15° to 60°',
      driveSystem: 'Shaft-mounted helical reducer with mechanical backstop',
      controlSystem: 'Reversible push-button station with emergency cable switch',
      contactParts: 'Molded Chevron Rubber, PVC Cleated, or Food-Grade Polyurethane',
      surfaceFinish: 'Heavy-duty industrial primer with synthetic enamel topcoat',
      inlet: 'Wide-mouth ground feed hopper with rubber skirting',
      outlet: 'Discharge chute, goose-neck horizontal discharge, or bagging head',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Limit switches for height stops, optical bag counters',
      optionalFeatures: 'Pneumatic truck loading boom, towable road wheels'
    },
    features: [
      'Non-Slip Molded Cleats & Chevrons ensuring zero product rollback even at steep 45° angles',
      'Hydraulic Height Adjustment allowing operators to adjust discharge heights to match trucks',
      'Heavy-Duty Pneumatic Wheels enabling easy maneuvering around factory yards and warehouses',
      'Mechanical Anti-Rollback Brake stopping belt instantly if power is cut under full load',
      'Reinforced Side Skirting keeping loose powders and grains inside the active belt width'
    ],
    applications: [
      {
        title: 'Truck & Container Loading',
        description: 'Loading 50kg bags of flour, sugar, cement, or grain into transport trucks.'
      },
      {
        title: 'Elevating Bulk Grains & Seeds',
        description: 'Lifting raw agriculture products into grain cleaning machines and dryers.'
      },
      {
        title: 'Waste & Scrap Handling',
        description: 'Conveying metal stampings, plastic bottles, and paper clippings into compactors.'
      }
    ],
    industries: [
      'Flour Mills & Grain Warehouses',
      'Sugar & Fertilizer Plants',
      'Logistics & Port Terminals',
      'Recycling & Waste Processing',
      'Construction Materials'
    ],
    benefits: [
      {
        title: 'Reduces Heavy Manual Labor',
        description: 'Eliminates the physical strain of carrying heavy bags up scaffolding or ladders.'
      },
      {
        title: 'Accelerates Vehicle Turnaround',
        description: 'Cuts loading and unloading times for semi-trailers by over 65%.'
      },
      {
        title: 'All-Weather Durability',
        description: 'Robust weather-resistant coatings operate reliably in outdoor yard environments.'
      }
    ],
    customizationOptions: [
      'Telescopic extending boom section for reaching deep into 40ft shipping containers',
      'Corrugated sidewall belts for vertical 90° pocket-lift conveying',
      'Variable speed drive for synchronized feed into packaging machines'
    ],
    relatedProductSlugs: ['belt-conveyor', 'bucket-conveyor', 'screw-conveyor', 'roller-conveyor']
  },

  {
    id: 'prod-fabric-rewinder',
    name: 'Textile Fabric Rewinder & Batching Machine',
    slug: 'fabric-rewinder',
    category: 'Textile Machinery',
    shortDescription: 'High-precision textile fabric rewinding, batching, and roll-to-roll winding machine engineered for uniform tension control, edge alignment, and accurate electronic length measurement.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Fabric Rewinder & Batching Machine is an industrial textile processing machine designed for rewinding, sizing, slitting, and converting rolls of fabric from large loom batches into tightly wound commercial rolls.',
      whatDoesItDo: 'It handles woven, knitted, denim, non-woven, and technical fabrics. The machine ensures that fabric rolls have straight edges, uniform winding density without creases, and precisely certified yardage/meterage counts.',
      howItWorks: 'The roll is mounted onto an unwinding spindle equipped with magnetic powder or pneumatic disc brakes for back-tension control. As the fabric travels through precision chrome-plated guide rollers, photo-electric edge tracking sensors detect selvedge misalignment and shift the rewinding carriage automatically. An electronic rotary encoder measures length while two driven surface rollers wind the finished roll under programmed tension.',
      whereItIsUsed: 'Textile processing mills, dyeing and printing units, denim finishing houses, garment manufacturing centers, and home textile export factories in Karachi, Faisalabad, and Lahore.',
      productionBenefits: 'Eliminates loose or skewed rolls, provides accurate meterage for billing, reduces edge trimming waste, and allows high-speed roll turnover (up to 120 meters/minute).',
      customEngineeringNote: 'TERAZ ENGINEERING customizes working widths from 1.6 meters up to 3.6 meters (wide-width home textiles), roll diameters up to 1,500mm, automatic cross-cut rotary cutters, and pneumatic roll doffing arms.'
    },
    mainImage: fabricRewinderImg,
    galleryImages: [
      {
        url: fabricRewinderImg,
        alt: 'TERAZ ENGINEERING industrial textile fabric rewinder and batching machine assembly',
        caption: 'Industrial fabric batching and rewinding machine with electronic meterage counter'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Precision chrome-plated guide rollers and expander bow roller on rewinder',
        caption: 'Hard-chrome plated expander bow roller eliminating fabric wrinkles and creases'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Photo-electric infrared selvedge edge guiding sensor and hydraulic actuator',
        caption: 'High-accuracy photoelectric edge sensor maintaining perfectly aligned roll edges'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Operator control panel with digital speed display, yard counter, and tension knob',
        caption: 'Touchscreen operator terminal with preset length stop and batch tally recording'
      }
    ],
    specifications: {
      machineType: 'Fabric Batching / Rewinding / Slitting Machine',
      model: 'TE-FR Series',
      capacity: 'Working Width: 1800mm to 3600mm; Roll Diameter: up to 1200mm',
      material: 'Solid structural steel side plates with hard chrome finished precision rolls',
      construction: 'Rigid vibration-free box frame with precision CNC bored bearing housings',
      motor: 'Dual AC Inverter Controlled Motors for unwind and rewind synchronization',
      motorPower: '3.7 kW to 11 kW',
      rpm: 'Operating winding speeds from 10 to 120 meters per minute (Stepless)',
      dimensions: 'Customized to fabric working width',
      driveSystem: 'Inverter-controlled geared motor with timing belt synchronization',
      controlSystem: 'Digital microprocessor or PLC with optical encoder and edge sensor',
      contactParts: 'Mirror-finish stainless steel guide plates and hard-chrome rollers',
      surfaceFinish: 'Industrial two-tone polyurethane paint with corrosion protection',
      inlet: 'A-frame unwinding stand or driven roll cradle for large jigger rolls',
      outlet: 'Surface contact winding cradle with pneumatic doffing kick-out arms',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Automatic edge guiding (EPC), programmable length stop, soft start',
      optionalFeatures: 'Inline ultrasonic fabric slitter, heated edge sealers, weighing scale'
    },
    features: [
      'Electronic Edge Guiding System (EPC) maintaining tight ±2mm roll edge alignment',
      'Electronic Meter / Yard Counter with preset automatic stop at targeted roll lengths',
      'Expander Bow Rollers actively stretching and flattening curly or creased fabric selvedges',
      'Adjustable Tension Control preventing fabric stretching on delicate knits or lycra blends',
      'Pneumatic Roll Ejection Arms allowing safe single-operator roll doffing onto carts',
      'Dual-Direction Forward & Reverse Jog for inspection and defect re-checking'
    ],
    applications: [
      {
        title: 'Denim & Heavy Cotton Batching',
        description: 'Converting loom rolls into large jumbo batches ready for continuous dyeing and sanforizing.'
      },
      {
        title: 'Knitted & Lycra Fabrics',
        description: 'Tension-controlled rewinding of delicate single jersey and fleece without permanent distortion.'
      },
      {
        title: 'Curtain & Home Textiles',
        description: 'Handling extra-wide (up to 3.6m) bedsheet and upholstery fabric with zero center sag.'
      },
      {
        title: 'Non-Woven & Technical Textiles',
        description: 'Slitting and rewinding geotextiles, medical fabrics, and filtration media.'
      }
    ],
    industries: [
      'Textile Mills & Weaving Units',
      'Dyeing, Printing & Finishing',
      'Denim Manufacturing',
      'Garment & Export Houses',
      'Non-Woven Fabric Production'
    ],
    benefits: [
      {
        title: 'Flawless Roll Presentation',
        description: 'Uniform edges and crease-free winding significantly enhance product value for buyers.'
      },
      {
        title: 'Accurate Certified Lengths',
        description: 'High-resolution digital optical encoders eliminate dispute-causing meterage discrepancies.'
      },
      {
        title: 'High Operator Productivity',
        description: 'Intuitive controls and pneumatic aids enable high roll turnover per shift.'
      }
    ],
    customizationOptions: [
      'Integrated circular slitting knives for multiple ribbon rolls from one wide beam',
      'A-frame to roll or roll to A-frame bi-directional conversion configurations',
      'Overhead inspection illumination canopy integration'
    ],
    relatedProductSlugs: ['fabric-inspection-machine', 'roller-conveyor', 'custom-machinery-fabrication', 'belt-conveyor']
  },

  {
    id: 'prod-fabric-inspection-machine',
    name: 'Illuminated Fabric Inspection & Quality Control Machine',
    slug: 'fabric-inspection-machine',
    category: 'Textile Machinery',
    shortDescription: 'Professional fabric inspection machine with dual top-and-bottom illumination panels, precision digital length measuring, defect tagging table, and variable speed drive.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Fabric Inspection Machine is a quality-assurance textile workstation designed for detecting weaving flaws, dyeing stains, holes, yarn slubs, and color shading variations across finished fabric rolls.',
      whatDoesItDo: 'It allows quality control inspectors to thoroughly examine moving fabric under controlled laboratory lighting, log defect coordinates according to international 4-point grading systems, and rewind the inspected fabric into perfect rolls.',
      howItWorks: 'Fabric unwinds smoothly from a roll or plaited fold and travels across a large angled milk-white acrylic inspection board illuminated from below by high-CRI flicker-free LED arrays. Overhead canopy fixtures provide calibrated surface light. The inspector can halt, reverse, or slow down the drive instantaneously using a full-width foot-pedal bar, mark flaws, and record defects.',
      whereItIsUsed: 'Crucial in textile export QA laboratories, garment cutting rooms, dyeing quality departments, and commercial fabric testing centers throughout Pakistan.',
      productionBenefits: 'Guarantees compliance with international export standards, catches defective fabric before it reaches expensive cutting stages, and provides documented inspection quality reports.',
      customEngineeringNote: 'TERAZ ENGINEERING manufactures custom inspection widths from 1,800mm to 3,600mm, dual-face inspection models, digital defect keyboard entry stations, and automatic width sensors.'
    },
    mainImage: fabricInspectionImg,
    galleryImages: [
      {
        url: fabricInspectionImg,
        alt: 'TERAZ ENGINEERING illuminated fabric inspection machine with lighted acrylic screen',
        caption: 'Heavy-duty inspection workstation featuring top canopy light and backlit acrylic table'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Milk-white inspection acrylic screen illuminated by high CRI daylight LEDs',
        caption: 'High-CRI daylight LED array highlighting weave density variations and pinholes'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Full-width safety emergency foot bar switch for instantaneous stopping',
        caption: 'Full-width foot bar allows hands-free halting from any standing position'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Digital length meter counter and variable speed potentiometer knob',
        caption: 'Precision length counter accurate to within ±0.1% of actual yardage'
      }
    ],
    specifications: {
      machineType: 'Fabric Inspection & Roll Quality Control Machine',
      model: 'TE-IM Series',
      capacity: 'Working Width: 1800mm to 3600mm; Roll Weight up to 500 kg',
      material: 'Reinforced tubular steel frame with anti-glare inspection board',
      construction: 'Ergonomic 45° angled inspection table with dual illumination chambers',
      motor: 'AC Variable Frequency Inverter Motor with instant dynamic braking',
      motorPower: '1.5 kW to 5.5 kW',
      rpm: 'Infinitely variable inspection speeds from 0 to 60 meters/minute',
      dimensions: 'Customized as per mill fabric width specification',
      driveSystem: 'Inverter geared motor driving rubber-sleeved traction rolls',
      controlSystem: 'Microprocessor counter with forward/reverse foot pedal bar',
      contactParts: 'Anti-static chrome rollers and food/textile-safe guide surfaces',
      surfaceFinish: 'Durable anti-rust powder coating with matt finish',
      inlet: 'Roll-to-roll cradle, flat fold plaited cart, or A-frame unwind',
      outlet: 'Tight surface winder with roll compactness adjustment',
      powerSupply: '220V Single Phase or 380V 3 Phase / 50 Hz',
      automation: 'Automatic edge sensor, preset length auto-stop, defect recording interface',
      optionalFeatures: 'Digital barcode flaw printer, fabric width digital measurement gauge'
    },
    features: [
      'Dual-Zone Illumination: Backlit translucent acrylic table combined with top daylight canopy',
      'Full-Width Foot Pedal Bar enabling instantaneous stopping anywhere along the machine',
      'Electronic Edge Sensor (EPC) ensuring that inspected rolls rewind with perfectly straight edges',
      'Forward and Reverse Drive for effortless re-examination of identified fabric flaws',
      'Digital Calibrated Meter Counter recording accurate roll length in meters or yards'
    ],
    applications: [
      {
        title: 'Export Fabric Quality Grading',
        description: 'Evaluating bulk rolls according to international 4-point defect grading standards.'
      },
      {
        title: 'Garment Cutting Room Verification',
        description: 'Verifying roll lengths and inspecting for shade bands before feeding automatic spreading tables.'
      },
      {
        title: 'Weaving & Dyeing Mills',
        description: 'Detecting loom stop marks, broken picks, misprints, and chemical stains promptly.'
      }
    ],
    industries: [
      'Textile Dyeing & Printing',
      'Garment Manufacturing & Apparel',
      'Export Quality Assurance',
      'Technical Fabrics & Composites'
    ],
    benefits: [
      {
        title: 'Defect Detection Before Cutting',
        description: 'Prevents cutting defective fabric into garments, saving thousands in scrap rejection.'
      },
      {
        title: 'Operator Ergonomics',
        description: 'Optimal 45° viewing angle and flicker-free lighting reduce inspector eye strain.'
      },
      {
        title: 'Accurate Length Billing',
        description: 'Prevents roll under-measurement and guarantees accurate commercial shipments.'
      }
    ],
    customizationOptions: [
      'Touchscreen data logger for recording flaw types and generating digital roll inspection scorecards',
      'Integrated digital fabric width measuring device displaying real-time width variances',
      'Plaited fabric fold-in to roll-out conversion adapters'
    ],
    relatedProductSlugs: ['fabric-rewinder', 'roller-conveyor', 'custom-machinery-fabrication', 'belt-conveyor']
  },

  {
    id: 'prod-industrial-hoppers-tanks',
    name: 'Stainless Steel Storage Hoppers & Pressure Vessel Mixing Tanks',
    slug: 'industrial-hoppers-tanks',
    category: 'Storage & Processing Vessels',
    shortDescription: 'Sanitary AISI 304 and 316 stainless steel storage hoppers, surge bins, blending tanks, and pressure vessels precision-fabricated for sanitary food, pharmaceutical, and chemical duty.',
    fullOverview: {
      whatIsIt: 'TERAZ ENGINEERING Industrial Hoppers & Tanks are custom-engineered stainless steel and carbon steel vessels designed for bulk storage, intermediate surge buffering, liquid mixing, and chemical process containment.',
      whatDoesItDo: 'They safely hold dry bulk powders, granules, liquids, syrups, and chemical solutions. Fabricated with conical, dished, or sloped discharge bottoms, they guarantee smooth, uniform mass flow without bridging or rat-holing.',
      howItWorks: 'Dry bulk material flows into the top inlet via pneumatic conveyors or bucket elevators. Steep conical bottom walls (60° to 70°) combined with sanitary butterfly or slide gates ensure smooth gravitational discharge. For liquid mixing tanks, high-torque central or side-entry agitator impellers blend liquids into consistent solutions under atmospheric or pressurized conditions.',
      whereItIsUsed: 'Indispensable across food processing plants, edible oil refineries, pharmaceutical batching plants, chemical synthesis facilities, beverage factories, and salt refineries across Pakistan.',
      productionBenefits: '100% corrosion-resistant sanitary stainless steel, continuous non-crevice TIG welds, sanitary CIP (Clean-In-Place) spray balls, and zero environmental contamination.',
      customEngineeringNote: 'TERAZ ENGINEERING custom-builds vessels from 100 Liters to 25,000 Liters, with insulation jackets for steam heating or glycol chilling, load-cell mounting brackets for loss-in-weight batching, and pneumatic fluidizer pads.'
    },
    mainImage: hopperTankImg,
    galleryImages: [
      {
        url: hopperTankImg,
        alt: 'TERAZ ENGINEERING stainless steel storage hopper and pressure vessel mixing tank',
        caption: 'Sanitary stainless steel conical bottom hopper mounted on structural support framework'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Internal sanitary mirror polish and continuous sanitary TIG weld seams',
        caption: 'Crevice-free internal finish polished to Ra < 0.4 µm for pharmaceutical compliance'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Sanitary manway hatch and CIP spray ball connection on vessel top dome',
        caption: 'Sanitary top manhole with quick-release clamps and rotary CIP spray ball'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Sanitary pneumatic butterfly discharge valve and load cell mounting lugs',
        caption: 'Pneumatic sanitary butterfly valve and precision load cell mounting pads'
      }
    ],
    specifications: {
      machineType: 'Storage Hopper / Mixing Vessel / Pressure Tank',
      model: 'TE-HT Series',
      capacity: '100 Liters to 25,000 Liters (Customizable to volume requirements)',
      material: 'AISI 304, AISI 316, or AISI 316L Stainless Steel (Carbon Steel for non-corrosive duty)',
      construction: 'Fully TIG welded with argon backing, dished/conical heads, reinforced legs',
      motor: 'Top-mounted industrial gearmotor for agitated mixing tanks (When equipped)',
      motorPower: '1.1 kW to 18.5 kW (Agitator matched)',
      rpm: '15 to 120 RPM (Slow anchor/paddle) or 750 to 1450 RPM (High-shear homogenizer)',
      dimensions: 'Custom diameter and height to fit plant ceiling clearances',
      driveSystem: 'Direct vertical flange-mounted gearmotor with sanitary mechanical shaft seal',
      controlSystem: 'Level switches (high/low), digital temperature controller, load-cell display',
      contactParts: 'Certified Food & Pharma Grade AISI 304 or 316L',
      surfaceFinish: 'Internal 2B, 180-grit, or 400-grit mirror polish; external scotch-brite or matte',
      inlet: 'Flanged tri-clamp connections, bag dump hood, or vacuum conveying port',
      outlet: 'Conical bottom with sanitary butterfly valve, ball valve, or rotary airlock flange',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Automatic level telemetry, automated heating cycle, batch dosing valves',
      optionalFeatures: 'Dimple jacket for steam/cooling, rockwool thermal insulation with SS cladding'
    },
    features: [
      'Crevice-Free Sanitary TIG Welds eliminating bacteria traps and ensuring effortless CIP sanitization',
      'Steep Hopper Cone Geometry preventing powder bridging, arching, and rat-holing during discharge',
      'Multi-Zone Agitation Systems available: anchor with Teflon scrapers, turbine, or high-shear cowles',
      'Precision Dimple Heating/Cooling Jackets engineered for steam, hot water, or chilled glycol',
      'Structural Stainless Steel Pipe Legs equipped with heavy-duty footplates and vibration pads'
    ],
    applications: [
      {
        title: 'Dry Powder Surge & Holding',
        description: 'Holding flour, milk powder, seasonings, spices, and grains above packaging machines.'
      },
      {
        title: 'Liquid Food & Beverage Blending',
        description: 'Mixing juices, sugar syrups, sauces, edible oils, and condiments uniformly.'
      },
      {
        title: 'Pharmaceutical Compounding',
        description: 'Sanitary holding and blending of syrups, suspensions, creams, and API solutions.'
      },
      {
        title: 'Chemical & Detergent Processing',
        description: 'Reaction and storage of liquid detergents, disinfectants, shampoos, and resins.'
      }
    ],
    industries: [
      'Food & Dairy Processing',
      'Pharmaceutical & Cosmetics',
      'Chemical & Petrochemical',
      'Beverage & Brewing',
      'Salt & Spice Refineries'
    ],
    benefits: [
      {
        title: 'Sanitary Food-Grade Compliance',
        description: 'Designed to conform to strict international hygiene and GMP standards.'
      },
      {
        title: 'Maximum Batch Drainability',
        description: 'Dished and conical bases ensure complete emptying with zero product loss.'
      },
      {
        title: 'Heavy Structural Integrity',
        description: 'Built with certified plate thicknesses engineered to withstand pressure and seismic loads.'
      }
    ],
    customizationOptions: [
      'Integrated pneumatic bin vibrators or fluidizing nozzles for stubborn cohesive powders',
      'Load-cell weighing frames for real-time loss-in-weight batch formulation',
      'Flame-proof (Ex-d) electrical motors for volatile solvent and chemical tanks'
    ],
    relatedProductSlugs: ['ribbon-mixer', 'screw-conveyor', 'sifter-vibrator', 'custom-machinery-fabrication']
  },

  {
    id: 'prod-sifter-vibrator',
    name: 'Industrial Circular Vibrating Screen Sifter (Vibro Sifter)',
    slug: 'sifter-vibrator',
    category: 'Screening & Separation Equipment',
    shortDescription: 'High-frequency circular vibrating sifter and screen separator for multi-deck classification, de-dusting, scalping, and liquid solid separation in food, chemical, and pharma plants.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Sifter Vibrator (Vibro Sifter) is a high-precision circular screening separator designed for accurate classification, de-lumping, grading, and foreign contaminant removal across dry powders and liquid slurries.',
      whatDoesItDo: 'It separates raw materials into discrete particle fractions, filters oversize foreign contaminants (scalping), eliminates fines or dust, and dewaters liquid slurries prior to mixing or packaging.',
      howItWorks: 'A heavy-duty vertical vibration motor mounted in the base features adjustable eccentric weights on both the top and bottom of the rotor shaft. The top weight generates horizontal planar movement, while the lower weight creates vertical tilting gyration. This generates a 3-dimensional multi-plane motion that drives particles across the fine stainless steel mesh in a spiral path toward the discharge spouts.',
      whereItIsUsed: 'Flour mills, spice processing plants, pharmaceutical granulation lines, chemical powder packaging, ceramics slip filtering, and salt plants across Pakistan.',
      productionBenefits: 'High throughput per square foot of screen area, rapid screen mesh change (under 5 minutes), self-cleaning ball trays preventing mesh blinding, and silent operation.',
      customEngineeringNote: 'TERAZ ENGINEERING builds vibro sifters from 600mm to 1,500mm diameter, with 1 to 4 separation decks, dust-tight top covers, ultrasonic de-blinding systems, and sanitary mirror finishes.'
    },
    mainImage: sifterVibratorImg,
    galleryImages: [
      {
        url: sifterVibratorImg,
        alt: 'TERAZ ENGINEERING stainless steel circular vibrating screen vibro sifter',
        caption: 'Multi-deck circular vibro sifter separator with stainless steel quick-clamp rings'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Internal view of precision stainless steel wire mesh screen and silicone cleaning rings',
        caption: 'Precision woven wire mesh screen equipped with anti-blinding silicone tapping balls'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Quick-release clamp ring assembly and discharge spouts on vibro sifter',
        caption: 'V-band clamp rings enabling tool-free screen changes in less than five minutes'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Vertical vibration motor with adjustable eccentric counterweights',
        caption: 'Heavy-duty dual-eccentric vibration motor mounted on precision isolation springs'
      }
    ],
    specifications: {
      machineType: 'Circular Gyro Vibrating Screen Sifter',
      model: 'TE-VS Series (600 / 800 / 1000 / 1200 / 1500)',
      capacity: '100 kg/hr to 5,000 kg/hr (Mesh size and material dependent)',
      material: 'AISI 304, AISI 316 Stainless Steel contact parts (Base in Carbon Steel)',
      construction: 'Quick-clamping modular screen decks with silicone food-grade gaskets',
      motor: 'Specialized High-Torque Vertical Vibration Motor',
      motorPower: '0.55 kW to 3.7 kW',
      rpm: '1440 RPM (Optimized high-frequency oscillation)',
      dimensions: 'Diameter: 600mm, 800mm, 1000mm, 1200mm, 1500mm',
      driveSystem: 'Direct eccentric shaft weights generating 3D multi-plane vibration',
      controlSystem: 'IP65 on/off push-button starter with thermal overload relay',
      contactParts: 'Food / Pharma Grade Stainless Steel AISI 304 or 316L',
      surfaceFinish: 'Mirror polished interior, satin bead blasted exterior',
      inlet: 'Center top charging inlet with dust-proof clamp lid',
      outlet: 'Multiple 360° orientable tangential discharge spouts',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Integrated continuous feed level monitoring and automated cut-off',
      optionalFeatures: 'Ultrasonic mesh anti-blinding converter, magnetic trap at outlet'
    },
    features: [
      'Three-Dimensional Gyro Motion maximizing screen contact time and separation sharpness',
      'Quick-Release V-Clamp Rings allowing complete mesh change and cleanout in under 5 minutes',
      'Anti-Blinding Ball Tray System using food-grade silicone balls to bounce against the mesh and prevent clogs',
      'Fully Enclosed Dust-Tight Operation preventing powder emissions into the factory environment',
      'Heavy-Duty Isolation Springs preventing vibration transfer to the workshop floor'
    ],
    applications: [
      {
        title: 'Flour & Bakery Premixes',
        description: 'Scalping insect fragments, thread, and agglomerated lumps prior to packing.'
      },
      {
        title: 'Spices & Seasoning Salts',
        description: 'Accurate particle sizing of chili, coriander, turmeric, and snack seasoning powders.'
      },
      {
        title: 'Pharmaceutical Granules',
        description: 'Grading tablet granules into fine, medium, and oversize fractions.'
      },
      {
        title: 'Chemicals & Pigments',
        description: 'Classification of toner, masterbatch pellets, sulfur, and paint pigment powders.'
      }
    ],
    industries: [
      'Food & Spice Processing',
      'Pharmaceuticals & Nutra',
      'Chemical & Pigments',
      'Ceramics & Minerals',
      'Plastics & Recycling'
    ],
    benefits: [
      {
        title: 'High Screening Accuracy',
        description: 'Separates up to 5 distinct particle fractions simultaneously in a single pass.'
      },
      {
        title: 'Zero Screen Clogging',
        description: 'Effective bounce ball trays prevent greasy or electrostatic powders from blinding mesh apertures.'
      },
      {
        title: 'Ultra-Compact Vertical Footprint',
        description: 'Fits directly into existing processing and packaging line drops.'
      }
    ],
    customizationOptions: [
      'Ultrasonic de-blinding excitation system for screening sub-100 micron fine powders',
      'Magnetic grate separator integrated inside the discharge chute for tramp metal capture',
      'Mobile castor wheel base for servicing multiple production stations'
    ],
    relatedProductSlugs: ['ribbon-mixer', 'screw-conveyor', 'hammer-mill-pulverizer', 'industrial-hoppers-tanks']
  },

  {
    id: 'prod-hammer-mill-pulverizer',
    name: 'Heavy-Duty Industrial Hammer Mill & Pin Mill Pulverizer',
    slug: 'hammer-mill-pulverizer',
    category: 'Milling & Grinding Machinery',
    shortDescription: 'Heavy-duty industrial hammer mill and high-speed pin mill pulverizers designed for fine grinding, crushing, and pulverizing of grains, spices, herbs, minerals, and chemicals.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Hammer Mill & Pin Mill Pulverizer is a high-speed size reduction machine engineered to crush, shatter, and pulverize dry solid raw materials into uniform granular or fine powder forms.',
      whatDoesItDo: 'It grinds tough, fibrous, or crystalline materials—such as whole spices (turmeric, coriander, cumin), grains, pulses, animal feed, dried herbs, sugar, salt, and industrial chemicals—down to desired mesh fines.',
      howItWorks: 'Raw material is fed into the crushing chamber via an adjustable feed hopper. Inside, high-speed hardened steel hammers or intermeshing pins rotate at 2,800 to 4,500 RPM. The incoming material is shattered by high-velocity kinetic impacts against the hammers and the serrated liner plates. Once particles are reduced small enough to pass through the perforated bottom screen, they are sucked into a cyclone collector or discharge hopper.',
      whereItIsUsed: 'Commercial spice mills, flour grinding factories, poultry and cattle feed plants, herbal medicine processors, salt plants, and mineral processing units in Pakistan.',
      productionBenefits: 'High grinding throughput, heavy hardened steel wear parts with extended life, easily replaceable sizing screens, and integrated cyclone dust collectors.',
      customEngineeringNote: 'TERAZ ENGINEERING manufactures mills with water-cooled grinding chambers (preventing heat-sensitive spices from losing aromatic essential oils), magnetic intake grates, and heavy-duty dynamically balanced rotors.'
    },
    mainImage: hammerMillImg,
    galleryImages: [
      {
        url: hammerMillImg,
        alt: 'TERAZ ENGINEERING heavy-duty industrial hammer mill pulverizer grinder',
        caption: 'Industrial heavy-duty hammer mill with heavy cast housing, cyclone and motor'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'High-speed rotor with dynamically balanced hardened steel hammers',
        caption: 'Dynamically balanced rotor fitted with hardened tungsten carbide faced hammers'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Perforated stainless steel sizing screen and serrated breaker plate liners',
        caption: 'Interchangeable heavy perforated sizing screens ranging from 0.5mm to 10mm'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Cyclone powder separator with rotary airlock valve and cloth filter bags',
        caption: 'High-efficiency cyclone collector delivering dustless packaging collection'
      }
    ],
    specifications: {
      machineType: 'High-Speed Impact Hammer Mill / Pin Mill Pulverizer',
      model: 'TE-HM Series',
      capacity: '150 kg/hr to 3,000 kg/hr (Material hardness and screen mesh matched)',
      material: 'Fabricated heavy carbon steel or AISI 304 stainless steel grinding chamber',
      construction: 'Reinforced 12mm to 20mm steel plate casing with dynamically balanced rotor',
      motor: 'Heavy-Duty 3-Phase TEFC High-Torque Electric Motor',
      motorPower: '7.5 kW to 55 kW',
      rpm: '2,800 to 4,500 RPM (High-velocity kinetic impact)',
      dimensions: 'Customized as per throughput and cyclone layout',
      driveSystem: 'V-belt drive with heavy multi-groove pulleys and safety cover guard',
      controlSystem: 'Star-Delta starter or Soft Starter with ammeter load gauge',
      contactParts: 'Hardened Alloy Steel (Hardox / EN8 / EN24) or Stainless Steel AISI 304',
      surfaceFinish: 'Heavy industrial anti-wear enamel coating',
      inlet: 'Feed hopper with manual slide gate and permanent magnetic separator grate',
      outlet: 'Bottom discharge into pneumatic suction pipe and cyclone dust collector',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Motor overload interlock automatically moderating vibrating feeder rate',
      optionalFeatures: 'Water-cooled jacket for temperature-sensitive spices, pneumatic conveying blower'
    },
    features: [
      'Dynamically Balanced Rotor eliminating destructive vibration and extending bearing service life',
      'Reversible Hardened Hammers offering four wearable impact edges before replacement is required',
      'Water-Cooled Housing Option keeping spice and chemical milling temperatures low to protect aromas',
      'Magnetic Intake Grid capturing stray tramp iron and nails before entering the grinding chamber',
      'Integrated Cyclone Discharge providing continuous dust-free product collection'
    ],
    applications: [
      {
        title: 'Spices & Condiments',
        description: 'Pulverizing dry turmeric roots, red chilies, black pepper, coriander seeds, and ginger.'
      },
      {
        title: 'Grains & Animal Feed',
        description: 'Milling corn, wheat, oats, soybean meal, and grain byproducts for livestock feeds.'
      },
      {
        title: 'Herbal & Ayurvedic Processing',
        description: 'Crushing medicinal roots, dried leaves, bark, and herbal preparations into fine powders.'
      },
      {
        title: 'Industrial Minerals & Chemicals',
        description: 'Grinding rock salt, gypsum, chalk, limestone, sulfur, and agricultural fertilizers.'
      }
    ],
    industries: [
      'Spice Mills & Seasoning Plants',
      'Animal & Poultry Feed Mills',
      'Herbal & Ayurvedic Medicine',
      'Chemical & Fertilizer Plants',
      'Food Processing & Bakeries'
    ],
    benefits: [
      {
        title: 'High Grinding Efficiency',
        description: 'Generates maximum fine mesh yield with low kWh power consumption per ton.'
      },
      {
        title: 'Low Wear and Replacement Costs',
        description: 'Wear parts are manufactured from hardened abrasion-resistant alloys.'
      },
      {
        title: 'Controlled Particle Size Distribution',
        description: 'Quick-change screen sieves allow fast switching between coarse granules and fine dust.'
      }
    ],
    customizationOptions: [
      'Dual-stage grinding setup with pre-crusher for large bulky roots and tubers',
      'Pulse-jet bag filter dust collector for sub-micron airborne dust recovery',
      'Variable speed inverter drive for optimizing rotor tip speeds per crop'
    ],
    relatedProductSlugs: ['sifter-vibrator', 'ribbon-mixer', 'screw-conveyor', 'industrial-hoppers-tanks']
  },

  {
    id: 'prod-continuous-fryer',
    name: 'Industrial Stainless Steel Continuous Snack Fryer',
    slug: 'continuous-fryer',
    category: 'Food Processing Machinery',
    shortDescription: 'Sanitary continuous industrial frying system with dual-hold conveyor belts, external heat exchanger, continuous oil filtration, and motorized hood lift for snacks and chips.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Continuous Snack Fryer is an automated industrial food processing system designed for continuous high-capacity frying of extruded snacks, potato chips, pellets, sev, samosas, and coated peanuts.',
      whatDoesItDo: 'It takes shaped wet or dry food items, continuously conveys them through precisely temperature-controlled edible oil, fries them to uniform golden crispness, drains excess oil, and discharges them onto seasoning tumblers.',
      howItWorks: 'Products enter the fryer inlet and are submerged beneath dual synchronized conveyor belts (a bottom carrier belt and a top hold-down belt). This prevents floating snacks from escaping or cooking unevenly. Hot cooking oil is continuously circulated from an external heat exchanger or direct burner chamber. A continuous paper or mesh oil filter continuously removes fines and crumbs, keeping oil free of degradation and extending oil frying life.',
      whereItIsUsed: 'Snack food factories, potato chip plants, nimko processing lines, commercial bakeries, and frozen food processing companies across Pakistan.',
      productionBenefits: 'Uniform golden product color, minimal oil turnover ratio, motorized hood lifting for rapid cleaning, and up to 40% savings in edible oil compared to manual batch vats.',
      customEngineeringNote: 'TERAZ ENGINEERING customizes fryer belt width (from 400mm to 1200mm), frying pan length (from 3m to 12m), gas-fired, diesel-fired, or electric heating systems, and motorized hood lifters.'
    },
    mainImage: continuousFryerImg,
    galleryImages: [
      {
        url: continuousFryerImg,
        alt: 'TERAZ ENGINEERING stainless steel continuous snack fryer processing line',
        caption: 'Full continuous frying system with motorized hood hoist and circulation piping'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Dual top-and-bottom wire mesh conveyor belts for submerged snack frying',
        caption: 'Dual synchronized stainless steel wire mesh belts ensuring complete product submersion'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Motorized screw jack hood lifting mechanism for comprehensive sanitary cleaning',
        caption: 'Electric screw-jack hood lift providing full 360° access for daily hygiene washdowns'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Digital PID temperature controller panel and circulation pump controls',
        caption: 'Precision multi-zone PID temperature controls maintaining constant cooking temperature'
      }
    ],
    specifications: {
      machineType: 'Continuous Submerged Belt Snack Fryer',
      model: 'TE-CF Series',
      capacity: '150 kg/hr to 1,500 kg/hr finished fried product',
      material: 'AISI 304 Food-Grade Stainless Steel throughout',
      construction: 'Insulated oil pan, motorized top hood lift, precision stainless mesh belts',
      motor: 'Synchronized variable speed geared motors for conveyor belts and oil pump',
      motorPower: '4 kW to 15 kW (Excluding burner and pump)',
      rpm: 'Frying transit times adjustable from 30 seconds to 6 minutes',
      dimensions: 'Belt width: 400mm to 1200mm; Pan Length: 3m to 10m',
      driveSystem: 'Inverter-controlled geared drives with stainless chain links',
      controlSystem: 'PLC with Touchscreen HMI and multi-point PID digital temperature controllers',
      contactParts: 'Certified Food Grade AISI 304 Stainless Steel',
      surfaceFinish: 'Sanitary brushed and bead blasted stainless steel finish',
      inlet: 'Vibratory product spreader feeder or drop chute',
      outlet: 'Inclined de-oiling wire mesh conveyor leading to seasoning drum',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Automatic low oil level safety shutoff, over-temperature alarm, motorized hood lift',
      optionalFeatures: 'Continuous paper belt oil filter, nitrogen blanket port, oil storage tank'
    },
    features: [
      'Dual Submerging Mesh Belts ensuring 100% uniform cooking without products floating unevenly',
      'Motorized Hood Jack Hoist lifting belts and hood completely out of the oil pan for fast cleaning',
      'Continuous Oil Circulation & Filtration sweeping crumb fines away before they burn and sour the oil',
      'Insulated Pan Walls reducing exterior thermal heat loss and keeping factory ambient air cool',
      'Low Oil Volume Engineering ensuring fast oil turnover and fresh, crispy fried snacks'
    ],
    applications: [
      {
        title: 'Potato Chips & Banana Wafers',
        description: 'Frying thin sliced potatoes and plantains to crispy golden perfection.'
      },
      {
        title: 'Extruded & Pellet Snacks',
        description: 'Expanding 2D and 3D corn, wheat, and potato snack pellets with uniform puffing.'
      },
      {
        title: 'Nimko, Sev & Dal Processing',
        description: 'Continuous continuous frying of chickpea sev, moong dal, and peanuts.'
      },
      {
        title: 'Samosas & Coated Finger Foods',
        description: 'Uniform frying of frozen cocktail samosas, spring rolls, and nuggets.'
      }
    ],
    industries: [
      'Snack Food Processing',
      'Commercial Bakeries & Nimko',
      'Frozen Prepared Foods',
      'Potato & Vegetable Processing'
    ],
    benefits: [
      {
        title: 'Dramatic Edible Oil Savings',
        description: 'Low total system oil volume coupled with continuous crumb filtration extends oil life.'
      },
      {
        title: 'Consistent Product Texture & Color',
        description: 'PID controlled temperature loops eliminate the dark and soggy batches common in manual vats.'
      },
      {
        title: 'Operator Safety & Hygiene',
        description: 'Enclosed design contains boiling oil splatters and vents steam vapors safely outdoors.'
      }
    ],
    customizationOptions: [
      'External shell-and-tube thermal oil heat exchanger for maximum fuel efficiency',
      'Stainless steel auxiliary clean oil storage tank with automatic level make-up pump',
      'De-oiling air knife blower at the discharge conveyor to strip excess surface oil'
    ],
    relatedProductSlugs: ['vegetable-washing-machine', 'belt-conveyor', 'ribbon-mixer', 'custom-machinery-fabrication']
  },

  {
    id: 'prod-vegetable-washing-machine',
    name: 'Industrial Fruit & Vegetable Bubble Washing Machine',
    slug: 'vegetable-washing-machine',
    category: 'Food Processing Machinery',
    shortDescription: 'Sanitary stainless steel air-bubble and high-pressure spray washing machine designed for gentle, non-destructive cleaning of vegetables, fruits, roots, and herbs.',
    fullOverview: {
      whatIsIt: 'The TERAZ ENGINEERING Fruit & Vegetable Washing Machine is an industrial continuous washer engineered to clean dirt, sand, insects, pesticides, and microbial residues from fruits, vegetables, leafy greens, roots, and herbs.',
      whatDoesItDo: 'It receives raw harvested agricultural produce, tumbles it gently inside an aerated water bath to release soil and contaminants without bruising the delicate skin, rinses the items with high-pressure clean water jets, and elevates them to inspection tables.',
      howItWorks: 'A high-pressure vortex air blower injects high-volume micro-bubbles into the bottom of the water tank. This generates a boiling tumbling water action that massages and turns the produce. Simultaneously, floating debris and insects are swept into an overflow collection weir. A wire mesh flighted elevator conveyor gently scoops up the clean produce, carrying it past a second stage of freshwater overhead spray nozzles before discharging onto sorting conveyors.',
      whereItIsUsed: 'Fruit pulping plants, vegetable freezing factories, pickle and sauce manufacturers, potato chip washing lines, and fresh salad packaging facilities across Pakistan.',
      productionBenefits: 'Zero damage to delicate skin and leaves, high washing throughput (up to 3 Tons/hour), continuous water recirculation filtration that saves fresh water, and complete AISI 304 food sanitation.',
      customEngineeringNote: 'TERAZ ENGINEERING offers customized tank lengths, ozone generator injection for microbial disinfection, rotary drum stone-and-sand traps, and roller brush peeling sections.'
    },
    mainImage: vegWasherImg,
    galleryImages: [
      {
        url: vegWasherImg,
        alt: 'TERAZ ENGINEERING stainless steel industrial fruit and vegetable bubble washing machine',
        caption: 'Full bubble washing tank with mesh elevator conveyor and water recirculation system'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'High-pressure air bubble bubbling bath churning produce gently without bruising',
        caption: 'Aerated water bath creating intense tumbling action that dislodges stubborn soil'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'Stainless steel wire mesh elevator discharge conveyor with secondary spray nozzles',
        caption: 'Secondary freshwater rinse stage washing away residual particles before discharge'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Water recirculation pump and multi-stage sediment filtration box',
        caption: 'Recirculation pump and filtration box cutting fresh water usage by over 70%'
      }
    ],
    specifications: {
      machineType: 'Continuous Air-Bubble & Spray Produce Washing Machine',
      model: 'TE-VW Series',
      capacity: '500 kg/hr to 5,000 kg/hr (Produce dependent)',
      material: 'AISI 304 Food-Grade Stainless Steel',
      construction: 'Full stainless steel tank with sloped sedimentation bottom and drain valves',
      motor: 'IP65 washdown geared motor for elevator conveyor and high-volume vortex blower',
      motorPower: '2.2 kW to 11 kW',
      rpm: 'Conveyor transit speed adjustable from 1 to 15 meters/minute',
      dimensions: 'Tank Length: 3m to 8m; Width: 800mm to 1400mm',
      driveSystem: 'Inverter-driven chain sprocket with stainless steel flighted mesh belt',
      controlSystem: 'Waterproof stainless steel electrical console with independent blower and pump switches',
      contactParts: 'Food Grade AISI 304 Stainless Steel',
      surfaceFinish: 'Sanitary bead blasted stainless steel',
      inlet: 'Wide-mouth produce receiving tank with water cushion',
      outlet: 'Elevated mesh conveyor discharge leading to sorting line',
      powerSupply: '380V - 415V / 3 Phase / 50 Hz',
      automation: 'Automatic water level float valve, conveyor speed regulation',
      optionalFeatures: 'Ozone sterilization generator, roller brush section for root vegetables'
    },
    features: [
      'Gentle Air Bubble Bath dislodging field mud and grit without bruising delicate leafy greens or fruit',
      'Dual Stage Cleaning combining deep immersion aeration with high-pressure clean water spray rinsing',
      'Sedimentation Trap Bottom settling heavy sand and stones into a bottom sump away from clean produce',
      'Water Recirculation Pump & Filter Box recycling filtered water to minimize water waste and utility bills',
      'Mesh Elevator Flighted Conveyor transporting clean produce out of the bath with zero manual handling'
    ],
    applications: [
      {
        title: 'Leafy Greens & Herbs',
        description: 'Washing spinach, coriander, mint, fenugreek, and lettuce without tearing leaves.'
      },
      {
        title: 'Root Vegetables & Tubers',
        description: 'Removing field dirt from potatoes, carrots, onions, beets, and ginger.'
      },
      {
        title: 'Fruits & Berries',
        description: 'Cleaning apples, mangoes, tomatoes, citrus, and strawberries before juice extraction.'
      },
      {
        title: 'Pickle & Vegetable Processing',
        description: 'Continuous washing of cucumbers, cauliflower, green chilies, and garlic cloves.'
      }
    ],
    industries: [
      'Fruit & Vegetable Processing',
      'Pickle, Chutney & Sauce Production',
      'Frozen Foods & IQF Lines',
      'Snack & Potato Chip Plants',
      'Fresh Produce Packaging'
    ],
    benefits: [
      {
        title: 'High Sanitization Standards',
        description: 'Rids produce of microbial contaminants, chemical pesticide residues, and insect matter.'
      },
      {
        title: 'Cuts Water Consumption',
        description: 'Recirculation system filters and reuses washing water, cutting facility water expenses.'
      },
      {
        title: 'Prevents Product Bruising',
        description: 'Fluidized water cushion protects delicate fruits from mechanical damage.'
      }
    ],
    customizationOptions: [
      'Ozone gas injection diffuser for chemical-free microbial elimination',
      'Integrated rotating drum screen for filtering out leaves and floating stems',
      'Inline air-knife drying tunnel directly following the elevator discharge'
    ],
    relatedProductSlugs: ['continuous-fryer', 'belt-conveyor', 'roller-conveyor', 'custom-machinery-fabrication']
  },

  {
    id: 'prod-custom-machinery-fabrication',
    name: 'Custom Industrial Machinery & Heavy Steel Fabrication',
    slug: 'custom-machinery-fabrication',
    category: 'Custom Engineering & Fabrication',
    shortDescription: 'Turnkey industrial engineering, precision machinery design, structural steel fabrication, pressure vessel welding, and customized manufacturing equipment built to client specifications.',
    fullOverview: {
      whatIsIt: 'TERAZ ENGINEERING Custom Machinery & Heavy Steel Fabrication service provides end-to-end mechanical design, structural fabrication, precision machining, and turnkey equipment manufacturing for industrial enterprises in Pakistan and globally.',
      whatDoesItDo: 'We engineer bespoke machines and complete production lines when off-the-shelf equipment does not fit your unique factory layout, material requirements, or capacity constraints. From concept CAD drafting to physical fabrication, commissioning, and plant integration, our Karachi facility delivers robust industrial solutions.',
      howItWorks: 'Our senior mechanical engineering team reviews your raw material properties, floor plans, and production targets. We generate 3D CAD models and structural calculations. Upon approval, our certified welders and machinists execute laser cutting, CNC bending, precision lathe turning, and sanitary TIG/MIG welding using certified stainless steel and carbon steel. Every unit undergoes strict quality inspection, motor load testing, and dimensional verification prior to delivery.',
      whereItIsUsed: 'Heavy manufacturing plants, food processing factories, chemical refineries, textile mills, paper mills, plastic extruders, and import-substitution projects throughout Pakistan.',
      productionBenefits: 'Tailored 100% to your facility constraints, built with heavy-gauge materials for exceptional durability, local Karachi availability of spare parts, and responsive on-site technical support.',
      customEngineeringNote: 'TERAZ ENGINEERING specializes in custom machinery adaptations, including plant debottlenecking, line extensions, reverse-engineering of obsolete imported machinery, and factory floor automation.'
    },
    mainImage: customFabImg,
    galleryImages: [
      {
        url: customFabImg,
        alt: 'TERAZ ENGINEERING custom machinery manufacturing and steel fabrication facility in Karachi',
        caption: 'Full heavy fabrication floor in SITE Area Karachi with precision machining and welding'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1200&q=80',
        alt: 'Precision TIG welding on heavy stainless steel pressure vessel frame',
        caption: 'Sanitary TIG welding performed by certified ASME/AWS standard welders'
      },
      {
        url: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80',
        alt: 'CNC bending, laser cutting, and precision lathe turning of machine components',
        caption: 'Precision CNC machined shafts, bearing blocks, and custom gears'
      },
      {
        url: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=1200&q=80',
        alt: 'Engineers conducting motor load test and electrical testing on custom machinery',
        caption: 'Full mechanical load testing and electrical safety audit prior to dispatch'
      }
    ],
    specifications: {
      machineType: 'Custom Engineered Industrial Machinery & Steel Fabrication',
      model: 'TE-Custom Series',
      capacity: 'Engineered entirely to client specifications and batch volumes',
      material: 'AISI 304, 316, 316L, Mild Steel, Hardox, Titanium / Hastelloy on request',
      construction: 'Heavy structural steel, precision CNC plate cutting, certified TIG/MIG welding',
      motor: 'Siemens, ABB, Motovario, or client-preferred international electric brands',
      motorPower: 'Available on Request (Calculated for exact process torque and duty cycle)',
      rpm: 'Customizable to process dynamics',
      dimensions: 'Designed to fit client floor dimensions and headroom clearance',
      driveSystem: 'Direct drive, helical gearbox, timing belt, or hydraulic power pack',
      controlSystem: 'Custom PLC Automation with Siemens / Delta / Schneider Touchscreens',
      contactParts: 'Certified Food / Pharma / Chemical Grade as specified',
      surfaceFinish: 'Mirror polish, bead blast, or multi-coat epoxy polyurethane industrial coating',
      inlet: 'Custom tailored to feed systems',
      outlet: 'Custom tailored to discharge systems',
      powerSupply: '220V Single Phase / 380V - 415V 3 Phase / 50Hz or 60Hz',
      automation: 'Fully bespoke automation from relay panels to SCADA line supervision',
      optionalFeatures: 'On-site installation, operator training, factory layout planning'
    },
    features: [
      'Tailored Mechanical Engineering eliminating compromises required by standard off-the-shelf equipment',
      'Heavy-Gauge Plate Construction ensuring decades of continuous vibration-free industrial operation',
      'Certified Sanitary TIG Welding suitable for strict food and pharmaceutical GMP environments',
      'Full Local After-Sales Support with rapid dispatch of technicians and readily available replacement parts',
      'Complete Turnkey Integration seamlessly connecting upstream and downstream processing machinery'
    ],
    applications: [
      {
        title: 'Import Substitution Machinery',
        description: 'Re-engineering expensive foreign machinery locally with heavy-duty construction and lower cost.'
      },
      {
        title: 'Custom Plant Expansion & De-Bottlenecking',
        description: 'Designing custom transition conveyors, hoppers, and mixers that fit tight existing layouts.'
      },
      {
        title: 'Specialized Chemical & Food Vessels',
        description: 'Fabricating non-standard reaction tanks, jacketed cookers, and high-pressure separators.'
      }
    ],
    industries: [
      'Food & Beverage',
      'Textile & Finishing',
      'Chemical & Petrochemical',
      'Pharmaceutical & Healthcare',
      'Heavy Manufacturing & Steel'
    ],
    benefits: [
      {
        title: 'Exact Fit For Your Process',
        description: 'Built specifically to accommodate your floor space, batch sizes, and physical products.'
      },
      {
        title: 'Substantial Capital Cost Savings',
        description: 'Delivers international-tier mechanical quality at domestic manufacturing prices.'
      },
      {
        title: 'Zero Downtime Sourcing Spares',
        description: 'All components, bearings, and motors use standard industrial parts stocked right in Karachi.'
      }
    ],
    customizationOptions: [
      'Complete 3D CAD modeling and process flow simulation prior to metal cutting',
      'Turnkey mechanical and electrical installation at your plant location',
      'Tailored preventive maintenance contracts and spare parts packages'
    ],
    relatedProductSlugs: ['ribbon-mixer', 'screw-conveyor', 'fabric-rewinder', 'industrial-hoppers-tanks']
  }
];

export const COMPANY_INFO = {
  name: 'TERAZ ENGINEERING',
  tagline: 'Custom Machinery Solutions',
  founder: 'Muhammad Iqbal',
  foundedYear: '2022',
  address: 'Plot # 45, Sector 12-C, North Karachi / SITE Industrial Area, Karachi, Sindh, Pakistan',
  locationCity: 'Karachi, Pakistan',
  phone: '+92 313 2513076',
  phoneRaw: '+923132513076',
  whatsappUrl: 'https://wa.me/923132513076?text=Hello%20TERAZ%20ENGINEERING,%20I%20am%20interested%20in%20your%20industrial%20machinery.',
  email: 'Terazengineer1930@gmail.com',
  secondaryEmail: 'rehaniqbal1930@gmail.com',
  businessHours: 'Monday – Saturday: 8:30 AM – 7:00 PM (PKT)',
  industriesServed: [
    'Food & Beverage Processing',
    'Textile & Garment Manufacturing',
    'Pharmaceutical & Healthcare',
    'Chemical, Soap & Detergent',
    'Plastics & Film Packaging',
    'Grain, Flour & Animal Feed Mills',
    'Heavy Steel & Custom Industrial Fabrication'
  ]
};
