import React, { useState } from 'react';
import {
  ChevronRight,
  ArrowLeft,
  MessageSquare,
  FileText,
  PhoneCall,
  CheckCircle2,
  Settings,
  ShieldCheck,
  Zap,
  Layers,
  Factory,
  ChevronLeft,
  Maximize2,
  Wrench,
  HelpCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { Product } from '../types';
import { COMPANY_INFO, PRODUCTS } from '../data/products';
import { MachineGalleryLightbox } from './MachineGalleryLightbox';
import { ProductCard } from './ProductCard';

interface ProductDetailPageProps {
  product: Product;
  onBackToProducts: () => void;
  onSelectProduct: (slug: string) => void;
  onRequestQuote: (productName: string) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  onBackToProducts,
  onSelectProduct,
  onRequestQuote,
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  // Filter related products
  const relatedProducts = PRODUCTS.filter((p) =>
    product.relatedProductSlugs.includes(p.slug)
  ).slice(0, 4);

  const handlePrevImage = () => {
    setActiveImageIndex(
      (prev) => (prev - 1 + product.galleryImages.length) % product.galleryImages.length
    );
  };

  const handleNextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % product.galleryImages.length);
  };

  const currentGalleryImg = product.galleryImages[activeImageIndex] || product.galleryImages[0];

  const handleWhatsAppInquiry = () => {
    const text = encodeURIComponent(
      `Hello TERAZ ENGINEERING,\n\nI am inquiring about the *${product.name}*.\nPlease share technical catalog, availability, and quotation for Karachi delivery.`
    );
    window.open(`https://wa.me/923132513076?text=${text}`, '_blank');
  };

  // Format specifications into readable table rows
  const specEntries = [
    { label: 'Machine Type', value: product.specifications.machineType },
    { label: 'Model Series', value: product.specifications.model },
    { label: 'Production Capacity', value: product.specifications.capacity },
    { label: 'Material Grade', value: product.specifications.material },
    { label: 'Construction', value: product.specifications.construction },
    { label: 'Motor Specification', value: product.specifications.motor },
    { label: 'Motor Power Rating', value: product.specifications.motorPower },
    { label: 'Operating Speed (RPM)', value: product.specifications.rpm },
    { label: 'Overall Dimensions', value: product.specifications.dimensions },
    { label: 'Drive Transmission', value: product.specifications.driveSystem },
    { label: 'Control System', value: product.specifications.controlSystem },
    { label: 'Contact Parts Material', value: product.specifications.contactParts },
    { label: 'Surface Finish', value: product.specifications.surfaceFinish },
    { label: 'Feed Inlet Design', value: product.specifications.inlet },
    { label: 'Discharge Outlet', value: product.specifications.outlet },
    { label: 'Power Supply', value: product.specifications.powerSupply },
    { label: 'Automation Level', value: product.specifications.automation },
    { label: 'Optional Engineering Features', value: product.specifications.optionalFeatures },
  ];

  return (
    <article id={`product-detail-${product.slug}`} className="min-h-screen bg-[#F4F7FA] pb-16">
      {/* Lightbox Modal */}
      <MachineGalleryLightbox
        images={product.galleryImages}
        initialIndex={activeImageIndex}
        isOpen={isLightboxOpen}
        onClose={() => setIsLightboxOpen(false)}
        productName={product.name}
      />

      {/* Breadcrumbs Bar */}
      <div className="bg-white border-b border-[#D9E1E8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between flex-wrap gap-2 text-xs text-[#667085]">
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={onBackToProducts}
              className="text-[#1565C0] hover:underline font-semibold"
            >
              Home
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
            <button
              onClick={onBackToProducts}
              className="text-[#1565C0] hover:underline font-semibold"
            >
              Machinery Products
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500 font-medium">{product.category}</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[#0B1F33] font-bold truncate max-w-xs">{product.name}</span>
          </nav>

          <button
            onClick={onBackToProducts}
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#1565C0] hover:text-[#0B1F33] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to All Machines
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* SECTION 4: PRODUCT HERO (Left: Large image & gallery / Right: Info & CTAs) */}
        <section className="bg-white rounded-xl border border-[#D9E1E8] shadow-sm overflow-hidden mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 lg:p-10">
            {/* Left: Gallery & Image Controls (7 cols) */}
            <div className="lg:col-span-7 flex flex-col">
              {/* Main Image Stage */}
              <div className="relative aspect-[4/3] bg-[#0B1F33]/5 rounded-lg overflow-hidden border border-[#D9E1E8] group">
                <img
                  src={currentGalleryImg.url}
                  alt={currentGalleryImg.alt}
                  className="w-full h-full object-cover select-none cursor-pointer"
                  onClick={() => setIsLightboxOpen(true)}
                  referrerPolicy="no-referrer"
                />

                {/* Top Overlay Badges */}
                <div className="absolute top-4 left-4 flex items-center gap-2">
                  <span className="px-3 py-1 bg-[#0B1F33]/90 text-white font-bold text-xs tracking-wider uppercase rounded backdrop-blur-sm shadow-sm">
                    {product.category}
                  </span>
                  <span className="px-2.5 py-1 bg-white/90 text-[#0B1F33] font-mono text-xs font-bold rounded shadow-sm">
                    {activeImageIndex + 1} / {product.galleryImages.length}
                  </span>
                </div>

                {/* Lightbox Trigger Button */}
                <button
                  id="open-lightbox-hero-btn"
                  onClick={() => setIsLightboxOpen(true)}
                  className="absolute top-4 right-4 p-2 bg-white/90 hover:bg-white text-[#0B1F33] rounded-lg shadow-md transition-all hover:scale-105"
                  title="Expand Full-Screen Gallery"
                  aria-label="Expand Full-Screen Gallery"
                >
                  <Maximize2 className="w-4 h-4" />
                </button>

                {/* Prev/Next Controls */}
                <button
                  id="hero-gallery-prev"
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePrevImage();
                  }}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-white/90 hover:bg-white text-[#0B1F33] shadow-lg transition-transform active:scale-95"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  id="hero-gallery-next"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleNextImage();
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-white/90 hover:bg-white text-[#0B1F33] shadow-lg transition-transform active:scale-95"
                  aria-label="Next image"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>

                {/* Bottom Caption Pill */}
                {currentGalleryImg.caption && (
                  <div className="absolute bottom-3 inset-x-3 bg-[#0B1F33]/85 text-white text-xs px-3 py-1.5 rounded backdrop-blur-sm font-medium line-clamp-1">
                    {currentGalleryImg.caption}
                  </div>
                )}
              </div>

              {/* Thumbnails Navigation Strip */}
              <div className="grid grid-cols-4 gap-3 mt-4">
                {product.galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative aspect-[4/3] rounded-md overflow-hidden border-2 transition-all ${
                      activeImageIndex === idx
                        ? 'border-[#1565C0] ring-2 ring-[#1565C0]/30 scale-[1.02]'
                        : 'border-[#D9E1E8] hover:border-slate-400 opacity-75 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img.url}
                      alt={img.alt}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Right: Product Hero Meta & Action Buttons (5 cols) */}
            <div className="lg:col-span-5 flex flex-col justify-between">
              <div>
                {/* Manufacturer Tag */}
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-bold tracking-widest text-[#1565C0] uppercase">
                    TERAZ ENGINEERING • KARACHI
                  </span>
                </div>

                {/* H1 Heading */}
                <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0B1F33] leading-tight mb-4">
                  {product.name}
                </h1>

                {/* Short Professional Introduction */}
                <p className="text-sm text-[#1F2933] leading-relaxed mb-6 font-medium">
                  {product.shortDescription}
                </p>

                {/* Key Quick Specifications Grid */}
                <div className="bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg p-4 mb-6 space-y-2.5">
                  <div className="flex justify-between items-center text-xs pb-2 border-b border-[#E2E8F0]">
                    <span className="text-[#667085] font-semibold">Standard Material:</span>
                    <span className="text-[#0B1F33] font-bold">{product.specifications.material || 'AISI 304 / 316 Stainless Steel'}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs pb-2 border-b border-[#E2E8F0]">
                    <span className="text-[#667085] font-semibold">Capacity Range:</span>
                    <span className="text-[#0B1F33] font-bold">{product.specifications.capacity || 'Customizable to Order'}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs pb-2 border-b border-[#E2E8F0]">
                    <span className="text-[#667085] font-semibold">Drive System:</span>
                    <span className="text-[#0B1F33] font-bold">{product.specifications.driveSystem || 'Heavy Geared Motor'}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[#667085] font-semibold">Manufacturing Origin:</span>
                    <span className="text-[#0B1F33] font-bold">SITE Industrial Area, Karachi</span>
                  </div>
                </div>
              </div>

              {/* Call to Actions (Section 4) */}
              <div className="space-y-3 pt-4 border-t border-[#D9E1E8]">
                {/* Primary CTA: Request a Quote */}
                <button
                  id="product-hero-request-quote-btn"
                  onClick={() => onRequestQuote(product.name)}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-6 bg-[#1565C0] hover:bg-[#0B2A4A] text-white font-bold text-sm rounded-lg shadow-md hover:shadow-lg transition-all duration-150"
                >
                  <FileText className="w-4 h-4" />
                  Request a Machine Quote
                </button>

                {/* WhatsApp & Call Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    id="product-hero-whatsapp-btn"
                    onClick={handleWhatsAppInquiry}
                    className="flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors shadow-sm"
                  >
                    <MessageSquare className="w-4 h-4" />
                    WhatsApp Inquiry
                  </button>

                  <a
                    id="product-hero-phone-btn"
                    href={`tel:${COMPANY_INFO.phoneRaw}`}
                    className="flex items-center justify-center gap-2 py-2.5 px-4 bg-[#0B1F33] hover:bg-[#17212B] text-white font-bold text-xs rounded-lg transition-colors shadow-sm"
                  >
                    <PhoneCall className="w-4 h-4" />
                    Call: {COMPANY_INFO.phone}
                  </a>
                </div>

                <p className="text-[11px] text-center text-[#667085] pt-1">
                  Custom engineering discussions and factory floor inspection available at our Karachi workshop.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 5: LONG PRODUCT OVERVIEW (500–900 words structured) */}
        <section className="bg-white rounded-xl border border-[#D9E1E8] p-6 lg:p-10 shadow-sm mb-12">
          <div className="border-b border-[#D9E1E8] pb-4 mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
              ENGINEERING ANALYSIS & TECHNICAL BRIEF
            </span>
            <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
              Comprehensive Machine Overview & Engineering Architecture
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 text-sm text-[#1F2933] leading-relaxed">
            {/* What is this machine? */}
            <div className="bg-[#F4F7FA] p-6 rounded-lg border border-[#D9E1E8]">
              <h3 className="text-base font-bold text-[#0B1F33] flex items-center gap-2 mb-3">
                <Factory className="w-5 h-5 text-[#1565C0]" />
                What is this machine?
              </h3>
              <p className="text-[#1F2933]">{product.fullOverview.whatIsIt}</p>
            </div>

            {/* What does it do? */}
            <div className="bg-[#F4F7FA] p-6 rounded-lg border border-[#D9E1E8]">
              <h3 className="text-base font-bold text-[#0B1F33] flex items-center gap-2 mb-3">
                <Settings className="w-5 h-5 text-[#1565C0]" />
                What does it do in production?
              </h3>
              <p className="text-[#1F2933]">{product.fullOverview.whatDoesItDo}</p>
            </div>

            {/* How does it work? */}
            <div className="bg-[#F4F7FA] p-6 rounded-lg border border-[#D9E1E8]">
              <h3 className="text-base font-bold text-[#0B1F33] flex items-center gap-2 mb-3">
                <Zap className="w-5 h-5 text-[#1565C0]" />
                How does it work? (Operating Principle)
              </h3>
              <p className="text-[#1F2933]">{product.fullOverview.howItWorks}</p>
            </div>

            {/* Where is it used? */}
            <div className="bg-[#F4F7FA] p-6 rounded-lg border border-[#D9E1E8]">
              <h3 className="text-base font-bold text-[#0B1F33] flex items-center gap-2 mb-3">
                <Layers className="w-5 h-5 text-[#1565C0]" />
                Where is it used? (Industrial Environments)
              </h3>
              <p className="text-[#1F2933]">{product.fullOverview.whereItIsUsed}</p>
            </div>

            {/* Production benefits */}
            <div className="bg-[#F4F7FA] p-6 rounded-lg border border-[#D9E1E8]">
              <h3 className="text-base font-bold text-[#0B1F33] flex items-center gap-2 mb-3">
                <ShieldCheck className="w-5 h-5 text-[#1565C0]" />
                Production & Efficiency Benefits
              </h3>
              <p className="text-[#1F2933]">{product.fullOverview.productionBenefits}</p>
            </div>

            {/* Custom engineering adaptation */}
            <div className="bg-[#F4F7FA] p-6 rounded-lg border border-[#D9E1E8]">
              <h3 className="text-base font-bold text-[#0B1F33] flex items-center gap-2 mb-3">
                <Wrench className="w-5 h-5 text-[#1565C0]" />
                Custom Engineering by TERAZ
              </h3>
              <p className="text-[#1F2933]">{product.fullOverview.customEngineeringNote}</p>
            </div>
          </div>
        </section>

        {/* SECTION 6: KEY FEATURES */}
        <section className="bg-white rounded-xl border border-[#D9E1E8] p-6 lg:p-10 shadow-sm mb-12">
          <div className="border-b border-[#D9E1E8] pb-4 mb-6">
            <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
              MECHANICAL ADVANTAGES
            </span>
            <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
              Engineered Key Features
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {product.features.map((feature, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-4 bg-[#F4F7FA] rounded-lg border border-[#D9E1E8]"
              >
                <CheckCircle2 className="w-5 h-5 text-[#1565C0] flex-shrink-0 mt-0.5" />
                <p className="text-xs sm:text-sm font-semibold text-[#1F2933] leading-snug">
                  {feature}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 7: TECHNICAL SPECIFICATIONS (Professional Table) */}
        <section className="bg-white rounded-xl border border-[#D9E1E8] p-6 lg:p-10 shadow-sm mb-12 overflow-hidden">
          <div className="border-b border-[#D9E1E8] pb-4 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
                MANUFACTURING BENCHMARKS
              </span>
              <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
                Technical Specifications
              </h2>
            </div>
            <span className="text-xs text-[#667085] bg-[#F4F7FA] px-3 py-1.5 rounded border border-[#D9E1E8] self-start">
              Custom ratings engineered upon request
            </span>
          </div>

          <div className="overflow-x-auto rounded-lg border border-[#D9E1E8]">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-[#0B1F33] text-white text-xs uppercase tracking-wider">
                  <th className="py-3.5 px-5 font-bold w-1/3 border-r border-slate-700">Specification Parameter</th>
                  <th className="py-3.5 px-5 font-bold">Standard Value / Engineering Capability</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E1E8]">
                {specEntries.map((spec, index) => {
                  if (!spec.value) return null;
                  return (
                    <tr
                      key={index}
                      className={index % 2 === 0 ? 'bg-white hover:bg-blue-50/40' : 'bg-[#F4F7FA] hover:bg-blue-50/40'}
                    >
                      <td className="py-3 px-5 font-bold text-[#0B1F33] border-r border-[#D9E1E8] text-xs sm:text-sm">
                        {spec.label}
                      </td>
                      <td className="py-3 px-5 text-[#1F2933] font-medium text-xs sm:text-sm">
                        {spec.value}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-[#667085] mt-3 italic">
            * Note: TERAZ ENGINEERING manufactures custom equipment. If your factory requires specific motor brands, custom RPM, dimensional constraints, or AISI 316L contact parts, specifications will be verified on official design CAD drawings.
          </p>
        </section>

        {/* SECTION 8: INDUSTRIES & APPLICATIONS */}
        <section className="bg-white rounded-xl border border-[#D9E1E8] p-6 lg:p-10 shadow-sm mb-12">
          <div className="border-b border-[#D9E1E8] pb-4 mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
              SECTOR RELEVANCE
            </span>
            <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
              Industries & Practical Applications
            </h2>
          </div>

          {/* Industry Badges */}
          <div className="mb-8">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#667085] mb-3">
              Target Manufacturing Sectors:
            </h3>
            <div className="flex flex-wrap gap-2">
              {product.industries.map((ind, idx) => (
                <span
                  key={idx}
                  className="px-3.5 py-1.5 bg-[#0B1F33] text-white text-xs font-bold rounded shadow-sm"
                >
                  {ind}
                </span>
              ))}
            </div>
          </div>

          {/* Application Detail Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {product.applications.map((app, idx) => (
              <div
                key={idx}
                className="p-5 bg-[#F4F7FA] rounded-lg border border-[#D9E1E8] hover:border-[#1565C0] transition-colors"
              >
                <h4 className="text-base font-bold text-[#0B1F33] mb-2">
                  {app.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
                  {app.description}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 9: MACHINE BENEFITS ("Why Choose This Machine?") */}
        <section className="bg-white rounded-xl border border-[#D9E1E8] p-6 lg:p-10 shadow-sm mb-12">
          <div className="border-b border-[#D9E1E8] pb-4 mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
              OPERATIONAL VALUE
            </span>
            <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
              Why Choose This Machine?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {product.benefits.map((benefit, idx) => (
              <div
                key={idx}
                className="flex items-start gap-4 p-5 bg-[#F4F7FA] rounded-lg border border-[#D9E1E8]"
              >
                <div className="w-10 h-10 rounded-lg bg-[#1565C0] text-white flex items-center justify-center flex-shrink-0 font-bold">
                  {idx + 1}
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0B1F33] mb-1">
                    {benefit.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
                    {benefit.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 10: CUSTOM ENGINEERING */}
        <section className="bg-gradient-to-r from-[#0B1F33] to-[#17212B] text-white rounded-xl p-8 lg:p-12 shadow-lg mb-12 border border-[#1565C0]/40">
          <div className="max-w-3xl">
            <span className="inline-block px-3 py-1 bg-[#1565C0] text-white text-xs font-bold uppercase tracking-wider rounded mb-3">
              BESPOKE INDUSTRIAL FABRICATION
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold mb-4">
              Customized Engineering Available
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              TERAZ ENGINEERING specializes in manufacturing tailor-made machinery to integrate into your existing factory setup. We can customize:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-8 text-xs sm:text-sm">
              {product.customizationOptions.map((opt, idx) => (
                <div key={idx} className="flex items-start gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-[#38BDF8] flex-shrink-0 mt-0.5" />
                  <span>{opt}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <button
                id="discuss-requirement-cta-btn"
                onClick={() => onRequestQuote(product.name)}
                className="px-6 py-3 bg-[#1565C0] hover:bg-[#2196F3] text-white font-bold text-sm rounded-lg shadow-md transition-colors"
              >
                Discuss Your Requirement
              </button>
              <button
                onClick={handleWhatsAppInquiry}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-lg shadow-md transition-colors flex items-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                WhatsApp Direct: +92 313 2513076
              </button>
            </div>
          </div>
        </section>

        {/* SECTION 11: MACHINE GALLERY SECTION */}
        <section className="bg-white rounded-xl border border-[#D9E1E8] p-6 lg:p-10 shadow-sm mb-12">
          <div className="border-b border-[#D9E1E8] pb-4 mb-8 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
                VISUAL INSPECTION
              </span>
              <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
                Machinery Workshop Gallery
              </h2>
            </div>
            <span className="text-xs text-[#667085] hidden sm:inline">
              Click any photo to open full-screen lightbox with zoom
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {product.galleryImages.map((img, idx) => (
              <div
                key={idx}
                onClick={() => {
                  setActiveImageIndex(idx);
                  setIsLightboxOpen(true);
                }}
                className="group relative aspect-[4/3] bg-[#0B1F33]/5 rounded-lg overflow-hidden border border-[#D9E1E8] cursor-pointer shadow-sm hover:shadow-md transition-all"
              >
                <img
                  src={img.url}
                  alt={img.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-[#0B1F33]/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="px-3 py-1.5 bg-[#0B1F33]/90 text-white text-xs font-bold rounded shadow flex items-center gap-1.5">
                    <Maximize2 className="w-3.5 h-3.5" /> Enlarge Photo
                  </span>
                </div>
                {img.caption && (
                  <div className="absolute bottom-0 inset-x-0 bg-[#0B1F33]/90 text-white text-[11px] p-2 line-clamp-1 font-medium">
                    {img.caption}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 12: RELATED MACHINERY (3-4 clickable related machines) */}
        {relatedProducts.length > 0 && (
          <section className="mb-12">
            <div className="border-b border-[#D9E1E8] pb-4 mb-6 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
                  PROCESS COMPATIBILITY
                </span>
                <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
                  Related Machinery & Upstream / Downstream Systems
                </h2>
              </div>
              <button
                onClick={onBackToProducts}
                className="text-xs font-bold text-[#1565C0] hover:underline hidden sm:inline"
              >
                View Full Catalog →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relProduct) => (
                <ProductCard
                  key={relProduct.id}
                  product={relProduct}
                  onSelectProduct={onSelectProduct}
                  onRequestQuote={onRequestQuote}
                />
              ))}
            </div>
          </section>
        )}

        {/* SECTION 13: ON-PAGE REQUEST A QUOTE (Pre-populates selected machine) */}
        <section id="quote-section" className="bg-white rounded-xl border border-[#D9E1E8] p-6 lg:p-10 shadow-sm">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
                DIRECT FACTORY PRICING
              </span>
              <h2 className="text-2xl font-bold text-[#0B1F33] mt-1">
                Request an Official Quote for {product.name}
              </h2>
              <p className="text-xs sm:text-sm text-[#667085] mt-2">
                Submit your technical requirements below. Our engineering team in SITE Area Karachi will calculate motor ratings, material thicknesses, and deliver a formal quotation.
              </p>
            </div>

            <div className="p-6 bg-[#F4F7FA] rounded-xl border border-[#D9E1E8]">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-[#0B1F33]">
                    Ready to discuss specifications?
                  </h3>
                  <p className="text-xs text-[#667085]">
                    Open our fast quote sheet or chat with Mr. Muhammad Iqbal directly on WhatsApp.
                  </p>
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <button
                    id="open-quote-modal-btn"
                    onClick={() => onRequestQuote(product.name)}
                    className="flex-1 sm:flex-none px-5 py-2.5 bg-[#1565C0] hover:bg-[#0B2A4A] text-white text-xs font-bold rounded-lg shadow-md transition-colors"
                  >
                    Open Quote Form
                  </button>
                  <button
                    onClick={handleWhatsAppInquiry}
                    className="flex-1 sm:flex-none px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-md transition-colors flex items-center justify-center gap-1.5"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    WhatsApp
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </article>
  );
};
