export interface ProductSpecification {
  machineType?: string;
  model?: string;
  capacity?: string;
  material?: string;
  construction?: string;
  motor?: string;
  motorPower?: string;
  rpm?: string;
  dimensions?: string;
  driveSystem?: string;
  controlSystem?: string;
  contactParts?: string;
  surfaceFinish?: string;
  inlet?: string;
  outlet?: string;
  powerSupply?: string;
  automation?: string;
  optionalFeatures?: string;
  [key: string]: string | undefined;
}

export interface ProductApplication {
  title: string;
  description: string;
}

export interface ProductBenefit {
  title: string;
  description: string;
}

export interface ProductCustomization {
  title: string;
  description: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category: string;
  shortDescription: string;
  fullOverview: {
    whatIsIt: string;
    whatDoesItDo: string;
    howItWorks: string;
    whereItIsUsed: string;
    productionBenefits: string;
    customEngineeringNote: string;
  };
  mainImage: string;
  galleryImages: {
    url: string;
    alt: string;
    caption?: string;
  }[];
  specifications: ProductSpecification;
  features: string[];
  applications: ProductApplication[];
  industries: string[];
  benefits: ProductBenefit[];
  customizationOptions: string[];
  relatedProductSlugs: string[];
}

export interface QuoteRequestData {
  productName: string;
  name: string;
  company: string;
  email: string;
  phoneOrWhatsApp: string;
  requiredCapacity: string;
  message: string;
}
