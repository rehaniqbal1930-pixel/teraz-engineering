import { useEffect } from 'react';
import { Product } from '../types';
import { COMPANY_INFO } from '../data/products';

interface SEOHeadProps {
  product?: Product | null;
  pageTitle?: string;
  pageDescription?: string;
  canonicalPath?: string;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  product,
  pageTitle,
  pageDescription,
  canonicalPath = '/',
}) => {
  useEffect(() => {
    // Determine title & description
    const title = product
      ? `${product.name} | TERAZ ENGINEERING Karachi`
      : pageTitle || 'TERAZ ENGINEERING | Industrial Machinery & Custom Engineering Solutions Karachi';

    const description = product
      ? `${product.shortDescription} Manufactured in Karachi, Pakistan by TERAZ ENGINEERING. Custom engineering, heavy-duty stainless steel fabrication.`
      : pageDescription || 'TERAZ ENGINEERING is a leading industrial machinery manufacturer in SITE Area Karachi, Pakistan. High-precision ribbon blenders, conveyors, textile machinery, hoppers, and custom fabrication.';

    document.title = title;

    // Update Meta description
    let metaDesc = document.querySelector('meta[name="description"]');
    if (!metaDesc) {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      document.head.appendChild(metaDesc);
    }
    metaDesc.setAttribute('content', description);

    // Update OpenGraph tags
    const updateOrCreateMeta = (property: string, content: string) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('property', property);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    updateOrCreateMeta('og:title', title);
    updateOrCreateMeta('og:description', description);
    updateOrCreateMeta('og:url', `https://terazengineering.com${canonicalPath}`);
    if (product) {
      updateOrCreateMeta('og:image', product.mainImage);
    }

    // Structured Data JSON-LD
    let scriptTag = document.getElementById('json-ld-structured-data') as HTMLScriptElement | null;
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = 'json-ld-structured-data';
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }

    const jsonLd = product
      ? {
          '@context': 'https://schema.org',
          '@type': 'Product',
          name: product.name,
          image: product.mainImage,
          description: product.shortDescription,
          category: product.category,
          brand: {
            '@type': 'Brand',
            name: COMPANY_INFO.name,
          },
          manufacturer: {
            '@type': 'Organization',
            name: COMPANY_INFO.name,
            address: {
              '@type': 'PostalAddress',
              streetAddress: COMPANY_INFO.address,
              addressLocality: 'Karachi',
              addressRegion: 'Sindh',
              addressCountry: 'Pakistan',
            },
            telephone: COMPANY_INFO.phone,
            email: COMPANY_INFO.email,
          },
        }
      : {
          '@context': 'https://schema.org',
          '@type': 'Organization',
          name: COMPANY_INFO.name,
          alternateName: 'TERAZ ENGINEERING PAKISTAN',
          url: 'https://terazengineering.com',
          logo: 'https://terazengineering.com/logo.svg',
          description: COMPANY_INFO.tagline,
          founder: {
            '@type': 'Person',
            name: COMPANY_INFO.founder,
          },
          foundingDate: COMPANY_INFO.foundedYear,
          address: {
            '@type': 'PostalAddress',
            streetAddress: COMPANY_INFO.address,
            addressLocality: 'Karachi',
            addressRegion: 'Sindh',
            addressCountry: 'Pakistan',
          },
          contactPoint: {
            '@type': 'ContactPoint',
            telephone: COMPANY_INFO.phone,
            contactType: 'Sales and Engineering Support',
            areaServed: 'PK',
            availableLanguage: ['English', 'Urdu'],
          },
        };

    scriptTag.textContent = JSON.stringify(jsonLd);
  }, [product, pageTitle, pageDescription, canonicalPath]);

  return null;
};
