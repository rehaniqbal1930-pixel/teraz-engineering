import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, MessageSquare, Send, PhoneCall } from 'lucide-react';
import { COMPANY_INFO } from '../data/products';
import { QuoteRequestData } from '../types';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultProductName?: string;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  isOpen,
  onClose,
  defaultProductName = '',
}) => {
  const [formData, setFormData] = useState<QuoteRequestData>({
    productName: defaultProductName,
    name: '',
    company: '',
    email: '',
    phoneOrWhatsApp: '',
    requiredCapacity: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (defaultProductName) {
      setFormData((prev) => ({ ...prev, productName: defaultProductName }));
    }
  }, [defaultProductName]);

  useEffect(() => {
    if (isOpen) {
      setSubmitted(false);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate reliable dispatch
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 600);
  };

  const handleWhatsAppForward = () => {
    const text = encodeURIComponent(
      `Hello TERAZ ENGINEERING,\n\nI would like to request an official quotation:\n*Product:* ${formData.productName || 'Industrial Machinery'}\n*Name:* ${formData.name}\n*Company:* ${formData.company || 'N/A'}\n*Capacity Required:* ${formData.requiredCapacity || 'Custom'}\n*Phone:* ${formData.phoneOrWhatsApp}\n*Message:* ${formData.message}`
    );
    window.open(`https://wa.me/923132513076?text=${text}`, '_blank');
  };

  return (
    <div
      id="quote-request-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0B1F33]/80 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative w-full max-w-xl bg-white rounded-xl shadow-2xl border border-[#D9E1E8] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#0B1F33] text-white">
          <div>
            <span className="text-[11px] font-bold tracking-widest uppercase text-[#38BDF8]">
              TERAZ ENGINEERING • OFFICIAL QUOTATION
            </span>
            <h3 className="text-xl font-bold">Request a Machine Quote</h3>
          </div>
          <button
            id="close-quote-modal-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close quote modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form or Submitted State */}
        {submitted ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-200">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-2xl font-bold text-[#0B1F33] mb-2">Quote Request Received!</h4>
            <p className="text-sm text-slate-600 max-w-md mx-auto mb-6">
              Thank you, <strong className="text-slate-800">{formData.name}</strong>. Our engineering sales team at TERAZ ENGINEERING (SITE Area Karachi) will review your requirements for{' '}
              <strong className="text-[#1565C0]">{formData.productName}</strong> and respond within 24 business hours.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={handleWhatsAppForward}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-sm transition-colors shadow-sm"
              >
                <MessageSquare className="w-4 h-4" />
                Connect on WhatsApp Now
              </button>
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg font-medium text-sm transition-colors"
              >
                Close Window
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* Pre-populated Machine Name */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Selected Machine / Equipment *
              </label>
              <input
                type="text"
                name="productName"
                value={formData.productName}
                onChange={handleChange}
                required
                className="w-full px-3.5 py-2.5 bg-[#F4F7FA] border border-[#D9E1E8] rounded-lg text-[#0B1F33] font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-[#1565C0] focus:border-[#1565C0]"
                placeholder="e.g. Ribbon Mixer, Screw Conveyor"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  placeholder="e.g. Tariq Mehmood"
                  className="w-full px-3.5 py-2 bg-white border border-[#D9E1E8] rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                />
              </div>

              {/* Company */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Company / Mill Name
                </label>
                <input
                  type="text"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="e.g. Al-Madina Foods Pvt Ltd"
                  className="w-full px-3.5 py-2 bg-white border border-[#D9E1E8] rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Email */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  placeholder="name@company.com"
                  className="w-full px-3.5 py-2 bg-white border border-[#D9E1E8] rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                />
              </div>

              {/* Phone / WhatsApp */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Phone / WhatsApp *
                </label>
                <input
                  type="tel"
                  name="phoneOrWhatsApp"
                  value={formData.phoneOrWhatsApp}
                  onChange={handleChange}
                  required
                  placeholder="+92 300 1234567"
                  className="w-full px-3.5 py-2 bg-white border border-[#D9E1E8] rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
                />
              </div>
            </div>

            {/* Required Capacity */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Required Capacity / Size
              </label>
              <input
                type="text"
                name="requiredCapacity"
                value={formData.requiredCapacity}
                onChange={handleChange}
                placeholder="e.g. 500 kg batch, 5 Tons/hr, or custom dimensions"
                className="w-full px-3.5 py-2 bg-white border border-[#D9E1E8] rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
              />
            </div>

            {/* Message */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Project Details / Technical Requirements
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={3}
                placeholder="Please describe your material characteristics (powder, liquid, bulk density), power supply, or specific automation needed..."
                className="w-full px-3.5 py-2 bg-white border border-[#D9E1E8] rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
              />
            </div>

            {/* Direct Contact Bar */}
            <div className="p-3 bg-[#F4F7FA] rounded-lg flex items-center justify-between text-xs text-slate-600 border border-[#D9E1E8]">
              <span>Direct Sales Desk:</span>
              <a
                href={`tel:${COMPANY_INFO.phoneRaw}`}
                className="font-bold text-[#1565C0] hover:underline flex items-center gap-1"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                {COMPANY_INFO.phone}
              </a>
            </div>

            {/* Submit Button */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                type="submit"
                id="submit-quote-form-btn"
                disabled={isSubmitting}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#1565C0] hover:bg-[#0B2A4A] text-white font-bold text-sm rounded-lg transition-colors shadow-md hover:shadow-lg disabled:opacity-50"
              >
                {isSubmitting ? (
                  'Processing...'
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Request Quote
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
