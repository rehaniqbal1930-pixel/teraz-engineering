import React, { useState } from 'react';
import {
  ArrowRight,
  PhoneCall,
  MessageSquare,
  ShieldCheck,
  CheckCircle2,
  Settings,
  Factory,
  Wrench,
  Layers,
  Sparkles,
  Zap,
  Clock,
  MapPin,
  Mail,
  ChevronRight
} from 'lucide-react';
import { ProductCard } from './ProductCard';
import { PRODUCTS, COMPANY_INFO } from '../data/products';
import { Product } from '../types';

interface HomePageProps {
  onSelectProduct: (slug: string) => void;
  onRequestQuote: (productName?: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onSelectProduct,
  onRequestQuote,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    'All',
    'Mixing & Blending',
    'Conveying & Material Handling',
    'Textile Machinery',
    'Size Reduction & Milling',
    'Separation & Screening',
    'Custom Industrial Systems',
  ];

  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory =
      selectedCategory === 'All' || product.category === selectedCategory;
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div id="homepage-root" className="bg-[#F4F7FA]">
      {/* 1. HERO SECTION */}
      <section className="relative bg-[#0B1F33] text-white overflow-hidden border-b border-[#17212B]">
        {/* Subtle geometric grid backdrop */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#2196F3_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1565C0]/30 border border-[#1565C0]/50 text-xs font-semibold tracking-wider uppercase text-[#38BDF8]">
                <ShieldCheck className="w-3.5 h-3.5" />
                SITE INDUSTRIAL AREA, KARACHI, PAKISTAN
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
                Precision Industrial Machinery & Custom Engineering Solutions
              </h1>

              <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
                TERAZ ENGINEERING designs and manufactures heavy-duty industrial processing equipment in Karachi. From stainless steel ribbon blenders and screw conveyors to specialized textile rewinding units and turnkey factory systems.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <a
                  href="#machinery-catalog"
                  className="px-6 py-3.5 bg-[#1565C0] hover:bg-[#2196F3] text-white font-bold text-sm rounded-lg shadow-lg hover:shadow-xl transition-all duration-150 inline-flex items-center gap-2"
                >
                  <span>Explore Machinery Catalog</span>
                  <ArrowRight className="w-4 h-4" />
                </a>

                <button
                  id="hero-request-quote-btn"
                  onClick={() => onRequestQuote()}
                  className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold text-sm rounded-lg border border-white/20 transition-colors"
                >
                  Request Fast Quote
                </button>

                <a
                  href={COMPANY_INFO.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-lg transition-colors inline-flex items-center gap-2 shadow-md"
                >
                  <MessageSquare className="w-4 h-4" />
                  WhatsApp Us
                </a>
              </div>

              {/* Key Trust Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-800 text-xs text-slate-300">
                <div className="border-l-2 border-[#1565C0] pl-3">
                  <div className="text-lg font-bold text-white">14+</div>
                  <div className="text-slate-400">Machine Categories</div>
                </div>
                <div className="border-l-2 border-[#1565C0] pl-3">
                  <div className="text-lg font-bold text-white">100%</div>
                  <div className="text-slate-400">In-House Karachi Mfg</div>
                </div>
                <div className="border-l-2 border-[#1565C0] pl-3">
                  <div className="text-lg font-bold text-white">AISI 304/316</div>
                  <div className="text-slate-400">Certified Food Grade</div>
                </div>
                <div className="border-l-2 border-[#1565C0] pl-3">
                  <div className="text-lg font-bold text-white">2022</div>
                  <div className="text-slate-400">Founded by M. Iqbal</div>
                </div>
              </div>
            </div>

            {/* Right Hero Image Card */}
            <div className="lg:col-span-5">
              <div className="relative rounded-xl overflow-hidden shadow-2xl border-2 border-[#1E3A5F] bg-[#17212B] group">
                <img
                  src="/src/assets/images/teraz_hero_banner_1790094633477.jpg"
                  alt="TERAZ ENGINEERING Industrial Machinery Manufacturing Workshop in Karachi"
                  className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1F33] via-transparent to-transparent opacity-80" />
                <div className="absolute bottom-4 inset-x-4 p-4 bg-[#0B1F33]/90 backdrop-blur-sm rounded-lg border border-[#1E3A5F]">
                  <p className="text-xs font-bold text-[#38BDF8] uppercase tracking-wider">
                    TERAZ HEAVY FABRICATION WORKSHOP
                  </p>
                  <p className="text-xs text-slate-200 mt-1">
                    Heavy structural welding, CNC profiling, balancing, and sanitary polishing in SITE Karachi.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. PRODUCT CATALOG SECTION (Section 16: Fully clickable cards) */}
      <section id="machinery-catalog" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
              COMPLETE INDUSTRIAL LINEUP
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0B1F33] mt-1">
              Industrial Machinery Catalog
            </h2>
            <p className="text-xs sm:text-sm text-[#667085] mt-1 max-w-2xl">
              Every machine is precision engineered at our Karachi facility. Click any machine card, image, or 'View Details' button to inspect full mechanical drawings, specifications, and workshop photos.
            </p>
          </div>

          {/* Quick Search */}
          <div className="w-full md:w-72">
            <input
              type="text"
              placeholder="Search machinery by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-3.5 py-2 text-xs bg-white border border-[#D9E1E8] rounded-lg text-[#0B1F33] focus:outline-none focus:ring-2 focus:ring-[#1565C0]"
            />
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-thin">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-colors flex-shrink-0 ${
                selectedCategory === cat
                  ? 'bg-[#1565C0] text-white shadow-sm'
                  : 'bg-white text-[#1F2933] border border-[#D9E1E8] hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid of Product Cards (All fully clickable to /products/:slug) */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl border border-[#D9E1E8] p-8">
            <Factory className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <p className="text-base font-bold text-[#0B1F33]">No machines found</p>
            <p className="text-xs text-[#667085] mt-1">Try changing your search term or category filter.</p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 bg-[#1565C0] text-white text-xs font-bold rounded-lg"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onSelectProduct={onSelectProduct}
                onRequestQuote={onRequestQuote}
              />
            ))}
          </div>
        )}
      </section>

      {/* 3. ENGINEERING CAPABILITIES & WORKSHOP SECTION */}
      <section className="bg-white border-y border-[#D9E1E8] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
              WORKSHOP EXCELLENCE
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0B1F33] mt-1">
              Engineered & Fabricated in Karachi, Pakistan
            </h2>
            <p className="text-xs sm:text-sm text-[#667085] mt-2">
              TERAZ ENGINEERING combines mechanical fabrication experience with sanitary stainless steel finishing standards to serve Pakistan's leading industrial processors.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-[#F4F7FA] rounded-xl border border-[#D9E1E8]">
              <div className="w-12 h-12 rounded-lg bg-[#1565C0] text-white flex items-center justify-center mb-4">
                <Wrench className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-[#0B1F33] mb-2">
                Heavy-Duty Fabrication
              </h3>
              <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
                TIG and MIG argon shielded welding on AISI 304 and AISI 316 stainless steel, heavy structural mild steel frames, dynamic balancing of rotating shafts, and precision flange machining.
              </p>
            </div>

            <div className="p-6 bg-[#F4F7FA] rounded-xl border border-[#D9E1E8]">
              <div className="w-12 h-12 rounded-lg bg-[#1565C0] text-white flex items-center justify-center mb-4">
                <Settings className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-[#0B1F33] mb-2">
                Tailored Drive & Automation
              </h3>
              <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
                Helical gearbox integration, explosion-proof motors, variable frequency drive (VFD) speed controllers, automated pneumatic discharge gates, and digital PLC control panels.
              </p>
            </div>

            <div className="p-6 bg-[#F4F7FA] rounded-xl border border-[#D9E1E8]">
              <div className="w-12 h-12 rounded-lg bg-[#1565C0] text-white flex items-center justify-center mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-[#0B1F33] mb-2">
                Testing & Local Karachi Support
              </h3>
              <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
                Every unit undergoes full dry-run vibration and load testing prior to factory dispatch. Because we are locally situated in SITE Karachi, spare parts and on-site support are always immediate.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. WHY CHOOSE TERAZ ENGINEERING */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-[#0B1F33] rounded-2xl text-white p-8 lg:p-12 overflow-hidden relative shadow-xl">
          <div className="relative z-10 max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-widest text-[#38BDF8]">
              INDUSTRIAL ADVANTAGE
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold mt-1 mb-4 text-white">
              Why Factory Owners in Pakistan Choose TERAZ ENGINEERING
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-8">
              Importing heavy machinery often involves prohibitive customs duties, currency conversion risks, delayed shipments, and missing spare parts. TERAZ ENGINEERING solves this with robust local engineering:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm mb-8">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#38BDF8] flex-shrink-0 mt-0.5" />
                <span><strong>Direct Manufacturer Pricing:</strong> Deal directly with the workshop without agency markups.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#38BDF8] flex-shrink-0 mt-0.5" />
                <span><strong>Custom Dimensional Fit:</strong> Sized to fit your exact building doorways and ceiling heights.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#38BDF8] flex-shrink-0 mt-0.5" />
                <span><strong>ASME & Sanitary Standards:</strong> Crevice-free polished welding for food and pharmaceutical purity.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#38BDF8] flex-shrink-0 mt-0.5" />
                <span><strong>Lifetime Support:</strong> Bearings, seals, gearboxes, and flightings readily available in Karachi.</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => onRequestQuote()}
                className="px-6 py-3 bg-[#1565C0] hover:bg-[#2196F3] text-white font-bold text-xs rounded-lg transition-colors shadow-md"
              >
                Request Plant Equipment Quote
              </button>
              <a
                href={`tel:${COMPANY_INFO.phoneRaw}`}
                className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-2 border border-white/20"
              >
                <PhoneCall className="w-4 h-4" />
                Call Founder: {COMPANY_INFO.phone}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 5. CONTACT & LOCATION SECTION */}
      <section className="bg-white border-t border-[#D9E1E8] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 space-y-4">
              <span className="text-xs font-bold uppercase tracking-widest text-[#1565C0]">
                VISIT OUR WORKSHOP
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0B1F33]">
                Conveniently Located in SITE Area, Karachi
              </h2>
              <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
                We invite plant managers, procurement engineers, and factory owners to visit our workshop to inspect active fabrication, review material certificates, and test machines in operation.
              </p>

              <div className="pt-4 space-y-3 text-xs sm:text-sm text-[#1F2933]">
                <div className="flex items-start gap-3 p-3 bg-[#F4F7FA] rounded-lg border border-[#D9E1E8]">
                  <MapPin className="w-5 h-5 text-[#1565C0] flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-[#0B1F33]">Workshop Address:</strong>
                    <span>{COMPANY_INFO.address}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#F4F7FA] rounded-lg border border-[#D9E1E8]">
                  <PhoneCall className="w-5 h-5 text-[#1565C0] flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-[#0B1F33]">Direct Engineering Line:</strong>
                    <a href={`tel:${COMPANY_INFO.phoneRaw}`} className="text-[#1565C0] hover:underline font-bold">
                      {COMPANY_INFO.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#F4F7FA] rounded-lg border border-[#D9E1E8]">
                  <Mail className="w-5 h-5 text-[#1565C0] flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-[#0B1F33]">Official Inquiries Email:</strong>
                    <a href={`mailto:${COMPANY_INFO.email}`} className="text-[#1565C0] hover:underline font-medium">
                      {COMPANY_INFO.email}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7">
              <div className="p-6 bg-[#F4F7FA] rounded-xl border border-[#D9E1E8]">
                <h3 className="text-lg font-bold text-[#0B1F33] mb-4">
                  Send Technical Inquiry to Engineering Desk
                </h3>
                <div className="space-y-4">
                  <p className="text-xs text-[#667085]">
                    Have a drawing or specification for a custom vessel, agitator, screw conveyor, or mixing plant? Our team in Karachi responds promptly with sizing and quote estimates.
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <button
                      onClick={() => onRequestQuote('Custom Plant Inquiry')}
                      className="px-6 py-3 bg-[#1565C0] hover:bg-[#0B2A4A] text-white text-xs font-bold rounded-lg shadow-sm"
                    >
                      Open In-App Quotation Form
                    </button>
                    <a
                      href={COMPANY_INFO.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      Chat on WhatsApp (+92 313 2513076)
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
